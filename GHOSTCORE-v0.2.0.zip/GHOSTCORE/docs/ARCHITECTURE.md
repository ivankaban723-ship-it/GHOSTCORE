# GHOSTCORE architecture

## Data flow

```
/proc ─► ProcfsCollector ─► ProcessMonitor ─► Engine.tick() ─► EventBus ─┬─► EventStore (SQLite)
                                  │               ▲                       ├─► GCPServer (Unix socket)
                                  │               └─ PluginManager        └─► other subscribers
                                  └─► PollResult ──(Qt signal)──► MainWindow ─► ProcessGraphView
```

- `collectors.procfs` parses `/proc` (state, CPU ticks, threads, uid, RSS, system stats).
- `core.monitor` diffs consecutive polls: CPU %, spawned/exited processes, GCP events.
  Identity is `pid:start_ticks`, so PID reuse creates a new node.
- `core.engine.Engine` is headless: one `tick()` = poll, publish, run plugins, prune history.
- `core.bus`, `core.store`, `core.transport` are independent subscribers.
- `core.layout` (radial + numpy force simulation) and `core.graph_model` hold all
  Qt-free graph logic so it is unit-tested.
- `ui.worker.EngineWorker` runs the engine on a `QThread`; results reach the GUI
  thread through a queued signal.

## Threading

Worker thread: collection, plugins, SQLite writes, socket broadcast.
GUI thread: rendering, layout animation, inspector. `GCPServer` uses an accept
thread plus one writer thread per client with a bounded queue; slow clients are dropped.

## Known limitations

- Force layout is O(n²) per step (≈8 ms at 900 nodes); above 900 nodes the view
  falls back to the radial layout.
- Plugins run in-process (no sandbox).
- The GUI shows live data only; history is queryable via CLI/DB.
- Reads of `/proc` are best effort: processes can vanish mid-read and are skipped.
