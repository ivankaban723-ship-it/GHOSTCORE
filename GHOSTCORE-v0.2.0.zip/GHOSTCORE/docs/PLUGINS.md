# Plugins

Subclass `ghostcore.plugins.api.GhostPlugin`, set `name`, optionally `version`
and `permissions`, and override `on_poll(result)` (called after every poll with
a `PollResult`) and/or `collect()`. See `examples/plugins/zombie_watch.py`.

Load with `--plugins-dir DIR` (files starting with `_` are skipped).

- **Trust:** discovery imports and runs the files. Use only directories you control.
- **Permissions:** declared in `permissions`; allowed by default: `process.read`,
  `system.read`. Unknown or disallowed ones reject the plugin. This is a gate,
  not isolation.
- **Isolation:** exceptions are caught; after 5 consecutive failures a plugin is disabled.
- **Events:** must be `GCPEvent`s outside the reserved `process.` / `system.` namespaces;
  others are dropped.
- Rejections are listed in the status bar / CLI warnings.
