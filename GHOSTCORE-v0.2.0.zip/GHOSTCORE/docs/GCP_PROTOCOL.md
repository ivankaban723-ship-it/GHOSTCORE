# GhostCore Protocol (GCP) v1

UTF-8 JSON Lines: one JSON object per line, at most 1 MiB per line.

Required fields: `protocol` (`"GCP"`), `version` (`1`), `type` (non-empty string),
`timestamp_ns` (non-negative integer, Unix ns), `payload` (object).

```json
{"protocol":"GCP","version":1,"type":"process.sample","timestamp_ns":123,"payload":{"pid":42,"node_id":"42:9001","cpu_percent":3.5,"memory_bytes":1048576,"state":"S","threads":4}}
```

## Core event types

| Type | When | Payload |
|---|---|---|
| `process.snapshot` | first poll; replayed to new socket clients | pid, ppid, node_id, name, state, memory_bytes, cpu_ticks, threads, uid |
| `process.spawned` | new process | same as snapshot |
| `process.exited` | process gone | pid, node_id, name |
| `process.sample` | state/memory changed or CPU ≥ 0.05 % | pid, node_id, cpu_percent, memory_bytes, state, threads |
| `system.sample` | every poll | load1/5/15, mem_total_bytes, mem_available_bytes, uptime_s, process_count |

`process.` and `system.` are reserved; plugin events (e.g. `alert.zombie`) must use other prefixes.
Command lines are never part of any event.

## Transport

Unix stream socket, server → client only. New clients first receive a
`process.snapshot` per live process, then live events. Socket mode is 0600; no
other authentication. Clients that cannot keep up are disconnected.
Version negotiation is still future work: decoders reject unknown versions.
