# Changelog

## 0.2.0
- Collector: CPU ticks, threads, uid, system stats; on-demand command line
- Engine, event bus, ProcessMonitor (CPU %, spawn/exit diffs), SQLite store, Unix socket transport
- Worker thread for collection (UI no longer blocks)
- Graph rewritten as incremental scene: states, sizes, CPU rings, ghosts, ancestry highlight,
  filter, radial/force layouts, drag pinning, zoom clamp (previously rebuilt every change)
- Inspector refreshes live, sparklines, top-CPU list, snapshot export
- Plugins: discovery, permissions, fault isolation, reserved namespaces
- Headless CLI (`watch`, `record`, `tail`, `history`), pyproject, CI, 70+ tests
- Fixed: scene state mutated inside `paint()`; inspector showed stale data; hardcoded interval text
