# GHOSTCORE

Linux process observability: a live, interactive process universe, a documented
event protocol (GCP), SQLite history, a Unix-socket stream and a plugin API.

## Features

- Live process graph: nodes coloured by state, sized by memory, ringed by CPU;
  spawns flash in next to their parent, exits fade out as red "ghosts"
- Two layouts: animated radial tree and a live force simulation (`L` to toggle)
- Inspector: user, threads, uptime, CPU/memory sparklines, command line (local only),
  ancestry trace highlighted on the graph, "Top CPU" list, filter box
- Collection runs on a worker thread; the UI never blocks on `/proc`
- GCP v1 events (JSON Lines): snapshot / spawned / exited / sample / system
- SQLite history with retention, Unix socket stream (mode 0600), headless CLI
- Plugin API with directory discovery, permissions and fault isolation

## Setup

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .          # optional: installs `ghostcore` and `ghostcore-cli`
```

## Run

```bash
python -m ghostcore.app                                   # GUI
python -m ghostcore.app --db ~/.ghostcore/h.db --socket /tmp/ghostcore.sock
python -m ghostcore.app --plugins-dir examples/plugins    # only trusted directories!
```

Without installing, prefix commands with `PYTHONPATH=src`.

Headless:

```bash
python -m ghostcore.cli watch                 # top-style terminal view (--once for one sample)
python -m ghostcore.cli record --db h.db --socket /tmp/gc.sock
python -m ghostcore.cli tail --socket /tmp/gc.sock --type process.
python -m ghostcore.cli history --db h.db --since 15m --type alert.
```

## Controls

| Input | Action |
|---|---|
| Scroll | zoom (clamped) |
| Drag empty space / node | pan / move node |
| Click node or "Top CPU" entry | inspect, trace ancestry |
| `F` / `R` / `L` | fit / re-layout / toggle layout |
| `Ctrl+F` `Ctrl+P` `Ctrl+E` | focus filter / pause / export snapshot |

Filter syntax: text matches name or PID; `state:Z` matches a process state.

## Test

```bash
python -m pytest -q
```

Qt-free logic (collector, monitor, store, transport, layouts, plugins, CLI) is
tested without a display. `tests/ui` runs against real Qt (offscreen) and is
skipped when PySide6 is missing.

## Privacy and security notes

- Command lines often contain secrets. They are read on demand for the local
  inspector only and never enter events, the database or the socket.
- The socket is created with mode 0600; there is no further authentication.
- Plugin discovery **executes** Python files. Permissions are declarative gates,
  not a sandbox. See `docs/PLUGINS.md`.

## Roadmap

- [x] Force-directed graph layout
- [x] Unix socket event transport
- [x] Plugin discovery and permissions (declarative)
- [x] SQLite event history
- [x] CPU and memory time series
- [ ] 3D visualization
- [ ] Optional C++ collector
- [ ] GUI history browser / time scrubbing
- [ ] Plugin sandboxing (subprocess isolation)
