import pytest

from ghostcore.core.protocol import MAX_EVENT_BYTES, EventType, GCPEvent


def test_event_round_trip():
    original = GCPEvent(
        event_type="process.snapshot",
        payload={"pid": 42, "name": "test process"},
        timestamp_ns=123456789,
    )
    restored = GCPEvent.decode(original.encode())
    assert restored.event_type == original.event_type
    assert restored.payload == original.payload
    assert restored.timestamp_ns == original.timestamp_ns
    assert restored.version == 1


def test_rejects_unknown_protocol():
    raw = (
        '{"protocol":"UNKNOWN","version":1,'
        '"type":"test","timestamp_ns":1,"payload":{}}'
    )
    with pytest.raises(ValueError, match="Unknown protocol"):
        GCPEvent.decode(raw)


def test_rejects_unsupported_version():
    raw = (
        '{"protocol":"GCP","version":999,'
        '"type":"test","timestamp_ns":1,"payload":{}}'
    )
    with pytest.raises(ValueError, match="Unsupported GCP version"):
        GCPEvent.decode(raw)


def test_rejects_invalid_payload():
    raw = (
        '{"protocol":"GCP","version":1,'
        '"type":"test","timestamp_ns":1,"payload":[]}'
    )
    with pytest.raises(ValueError, match="payload"):
        GCPEvent.decode(raw)


def test_rejects_bool_and_negative_timestamps():
    for ts in ("true", "-1", "1.5", '"1"'):
        raw = '{"protocol":"GCP","version":1,"type":"t","timestamp_ns":%s,"payload":{}}' % ts
        with pytest.raises(ValueError, match="timestamp"):
            GCPEvent.decode(raw)


def test_rejects_non_object_and_garbage():
    with pytest.raises(ValueError):
        GCPEvent.decode("[]")
    with pytest.raises(ValueError):
        GCPEvent.decode("not json")


def test_size_limits_both_directions():
    huge = GCPEvent("t", {"blob": "x" * MAX_EVENT_BYTES}, 1)
    with pytest.raises(ValueError, match="MAX_EVENT_BYTES"):
        huge.encode()
    with pytest.raises(ValueError, match="MAX_EVENT_BYTES"):
        GCPEvent.decode(b"x" * (MAX_EVENT_BYTES + 1))


def test_node_id_property_and_unicode_round_trip():
    event = GCPEvent(EventType.PROCESS_SAMPLE, {"node_id": "1:2", "name": "процесс"}, 5)
    assert event.node_id == "1:2"
    assert GCPEvent.decode(event.encode()).payload["name"] == "процесс"
    assert GCPEvent("t", {"node_id": 5}, 1).node_id is None
    assert event.encode().endswith(b"\n") and event.encode().count(b"\n") == 1
