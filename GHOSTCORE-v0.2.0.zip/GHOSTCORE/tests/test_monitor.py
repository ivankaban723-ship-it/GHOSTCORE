from ghostcore.collectors.procfs import ProcfsCollector
from ghostcore.core.monitor import ProcessMonitor
from ghostcore.core.protocol import EventType

from conftest import write_proc


class Clock:
    def __init__(self):
        self.t = 100.0

    def __call__(self):
        return self.t


def make(fake_proc):
    clock = Clock()
    collector = ProcfsCollector(fake_proc)
    collector.clock_ticks = 100
    return ProcessMonitor(collector, clock=clock, wall_clock_ns=lambda: 5), clock


def by_type(events):
    out = {}
    for e in events:
        out.setdefault(e.event_type, []).append(e)
    return out


def test_first_poll_emits_snapshots_and_system(fake_proc):
    write_proc(fake_proc, 1, name="init", ppid=0)
    write_proc(fake_proc, 2, name="child", ppid=1)
    monitor, _ = make(fake_proc)
    result = monitor.poll()
    assert result.first and result.cpu_percent == {} and result.interval_s == 0
    kinds = by_type(monitor.to_events(result))
    assert len(kinds[EventType.PROCESS_SNAPSHOT]) == 2
    assert len(kinds[EventType.SYSTEM_SAMPLE]) == 1
    assert EventType.PROCESS_SPAWNED not in kinds


def test_cpu_percent_from_tick_delta(fake_proc):
    write_proc(fake_proc, 1, utime=0)
    monitor, clock = make(fake_proc)
    monitor.to_events(monitor.poll())
    clock.t += 2.0
    write_proc(fake_proc, 1, utime=100)            # 100 ticks = 1 s CPU in 2 s
    result = monitor.poll()
    assert abs(result.cpu_of("1:100") - 50.0) < 1e-6
    assert abs(result.interval_s - 2.0) < 1e-9


def test_cpu_counter_going_backwards_is_clamped(fake_proc):
    write_proc(fake_proc, 1, utime=500)
    monitor, clock = make(fake_proc)
    monitor.poll()
    clock.t += 1
    write_proc(fake_proc, 1, utime=10)
    assert monitor.poll().cpu_of("1:100") == 0.0


def test_spawn_exit_and_pid_reuse(fake_proc):
    import shutil
    write_proc(fake_proc, 1, start=10)
    write_proc(fake_proc, 2, start=20)
    monitor, clock = make(fake_proc)
    monitor.to_events(monitor.poll())
    clock.t += 1
    shutil.rmtree(fake_proc / "2")
    write_proc(fake_proc, 3, start=30)
    result = monitor.poll()
    assert [s.pid for s in result.spawned] == [3]
    assert [s.pid for s in result.exited] == [2]
    kinds = by_type(monitor.to_events(result))
    assert kinds[EventType.PROCESS_EXITED][0].payload["node_id"] == "2:20"
    assert kinds[EventType.PROCESS_SPAWNED][0].payload["pid"] == 3

    # PID 2 comes back with a different start time: it is a NEW process.
    clock.t += 1
    write_proc(fake_proc, 2, start=99)
    result = monitor.poll()
    assert [s.node_id for s in result.spawned] == ["2:99"]


def test_samples_only_when_something_changed(fake_proc):
    write_proc(fake_proc, 1, rss_kib=100)
    write_proc(fake_proc, 2, rss_kib=100)
    monitor, clock = make(fake_proc)
    monitor.to_events(monitor.poll())
    clock.t += 1
    write_proc(fake_proc, 2, rss_kib=200)           # memory changed
    events = by_type(monitor.to_events(monitor.poll()))
    samples = events[EventType.PROCESS_SAMPLE]
    assert [e.payload["pid"] for e in samples] == [2]
    clock.t += 1
    assert EventType.PROCESS_SAMPLE not in by_type(monitor.to_events(monitor.poll()))
    clock.t += 1
    write_proc(fake_proc, 1, rss_kib=100, utime=50)  # busy CPU, same memory
    events = by_type(monitor.to_events(monitor.poll()))
    assert [e.payload["pid"] for e in events[EventType.PROCESS_SAMPLE]] == [1]
    assert events[EventType.PROCESS_SAMPLE][0].payload["cpu_percent"] > 0


def test_snapshot_events_reflect_latest_state(fake_proc):
    write_proc(fake_proc, 1)
    monitor, _ = make(fake_proc)
    assert monitor.snapshot_events() == []
    monitor.poll()
    assert [e.payload["pid"] for e in monitor.snapshot_events()] == [1]
