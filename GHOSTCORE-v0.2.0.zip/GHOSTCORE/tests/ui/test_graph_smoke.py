"""Smoke test against real Qt (offscreen). Skipped when PySide6 is missing."""

import os

import pytest

pytest.importorskip("PySide6")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from ghostcore.collectors.procfs import ProcessSnapshot  # noqa: E402
from ghostcore.ui.graph_view import ProcessGraphView  # noqa: E402


def P(pid, ppid, name="p", state="S", start=None):
    return ProcessSnapshot(pid, ppid, name, state, 1 << 20, start or pid)


def test_graph_lifecycle_under_real_qt():
    app = QApplication.instance() or QApplication([])
    view = ProcessGraphView()
    base = [P(1, 0, "init"), P(2, 1, "a"), P(3, 1, "b")]

    view.update_processes(base, {"2:2": 40.0})
    assert view.node_count == 3

    view.update_processes(base + [P(4, 2, "c")], {})
    assert view.node_count == 4

    view.update_processes(base, {})                 # c exits -> ghost, then removed
    assert view.node_count == 3
    for _ in range(120):
        view._tick()
    assert not view._ghosts

    view.set_layout_mode("force")
    for _ in range(50):
        view._tick()
    view.set_filter("state:z")
    view.select_node("2:2")
    view.set_layout_mode("radial")
    view.update_processes([], {})
    assert view.node_count == 0
    app.processEvents()
