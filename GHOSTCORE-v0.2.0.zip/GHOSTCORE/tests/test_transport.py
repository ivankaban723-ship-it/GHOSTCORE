import os
import socket
import tempfile
import threading
import time

import pytest

from ghostcore.core.protocol import GCPEvent
from ghostcore.core.transport import GCPServer, stream_events


def wait_for(predicate, timeout=3.0):
    end = time.time() + timeout
    while time.time() < end:
        if predicate():
            return True
        time.sleep(0.01)
    return False


def sock_path():
    return os.path.join(tempfile.mkdtemp(prefix="gc"), "s.sock")


def read_n(path, n, out):
    for event in stream_events(path, timeout=3):
        out.append(event)
        if len(out) >= n:
            return


def test_snapshot_replay_then_live_broadcast():
    path = sock_path()
    snap = [GCPEvent("process.snapshot", {"pid": 1}, 1)]
    server = GCPServer(path, snapshot_provider=lambda: snap)
    server.start()
    try:
        assert oct(os.stat(path).st_mode & 0o777) == "0o600"
        got = []
        t = threading.Thread(target=read_n, args=(path, 3, got))
        t.start()
        assert wait_for(lambda: server.client_count == 1)
        server.broadcast([GCPEvent("a", {}, 2), GCPEvent("b", {}, 3)])
        t.join(timeout=5)
        assert [e.event_type for e in got] == ["process.snapshot", "a", "b"]
    finally:
        server.close()
    assert not os.path.exists(path)


def test_multiple_clients_and_disconnect():
    path = sock_path()
    server = GCPServer(path)
    server.start()
    try:
        outs = [[], []]
        threads = [threading.Thread(target=read_n, args=(path, 1, o)) for o in outs]
        for t in threads:
            t.start()
        assert wait_for(lambda: server.client_count == 2)
        server.broadcast([GCPEvent("x", {}, 1)])
        for t in threads:
            t.join(timeout=5)
        assert all(len(o) == 1 for o in outs)
        assert wait_for(lambda: server.client_count == 0)   # they hung up
        server.broadcast([GCPEvent("x", {}, 2)])             # no clients: no-op
    finally:
        server.close()


def test_slow_client_is_dropped_not_blocking():
    path = sock_path()
    server = GCPServer(path, queue_size=2)
    server.start()
    raw = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        raw.connect(path)                    # connects but never reads
        assert wait_for(lambda: server.client_count == 1)
        big = [GCPEvent("x", {"blob": "y" * 200_000}, i) for i in range(5)]
        for _ in range(60):
            server.broadcast(big)            # must never block
            if server.client_count == 0:
                break
        assert wait_for(lambda: server.client_count == 0)
    finally:
        raw.close()
        server.close()


def test_stale_socket_replaced_live_one_refused_and_regular_file_protected(tmp_path):
    path = sock_path()
    stale = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    stale.bind(path)
    stale.close()                            # file remains, nobody listens
    first = GCPServer(path)
    first.start()
    try:
        with pytest.raises(OSError, match="already served"):
            GCPServer(path).start()
    finally:
        first.close()

    regular = tmp_path / "not-a-socket"
    regular.write_text("precious")
    with pytest.raises(FileExistsError):
        GCPServer(regular).start()
    assert regular.read_text() == "precious"


def test_stream_rejects_garbage_lines():
    path = sock_path()
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    listener.bind(path)
    listener.listen(1)

    def serve():
        conn, _ = listener.accept()
        conn.sendall(b"\n{\"not\":\"gcp\"}\n")
        conn.close()

    threading.Thread(target=serve, daemon=True).start()
    try:
        with pytest.raises(ValueError):
            list(stream_events(path, timeout=3))
    finally:
        listener.close()
