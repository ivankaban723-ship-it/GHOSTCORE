"""Shared helpers: a fake /proc tree builder."""

from pathlib import Path

import pytest

STAT_TEMPLATE = (
    "{pid} ({name}) {state} {ppid} 0 0 0 0 0 0 0 0 0 {utime} {stime} 0 0 20 0 "
    "{threads} 0 {start} 0 0\n"
)


def write_proc(root: Path, pid: int, name="proc", state="S", ppid=1, utime=0,
               stime=0, threads=1, start=100, rss_kib=1024, uid=1000, cmdline=b""):
    d = root / str(pid)
    d.mkdir(parents=True, exist_ok=True)
    (d / "stat").write_text(STAT_TEMPLATE.format(
        pid=pid, name=name, state=state, ppid=ppid, utime=utime, stime=stime,
        threads=threads, start=start))
    (d / "status").write_text(f"Name:\t{name}\nUid:\t{uid}\t{uid}\t{uid}\t{uid}\nVmRSS:\t{rss_kib} kB\n")
    (d / "cmdline").write_bytes(cmdline)


def write_system(root: Path, load="0.50 0.40 0.30 1/100 999", uptime="1000.50 900.00",
                 total_kib=8_000_000, avail_kib=2_000_000):
    (root / "loadavg").write_text(load + "\n")
    (root / "uptime").write_text(uptime + "\n")
    (root / "meminfo").write_text(
        f"MemTotal:       {total_kib} kB\nMemFree:         100 kB\nMemAvailable:   {avail_kib} kB\n")


@pytest.fixture
def fake_proc(tmp_path):
    root = tmp_path / "proc"
    root.mkdir()
    write_system(root)
    return root
