from ghostcore.collectors.procfs import ProcessSnapshot, SystemStats
from ghostcore.core.monitor import PollResult
from ghostcore.core.series import SeriesStore


def result(pids, cpu, mem=100):
    snaps = tuple(ProcessSnapshot(p, 1, "p", "S", mem, p) for p in pids)
    system = SystemStats(0, 0, 0, 100, 50, 1.0)
    return PollResult(1, 1.0, snaps, {f"{p}:{p}": cpu for p in pids}, system=system)


def test_records_trims_and_forgets_exited():
    store = SeriesStore(maxlen=3)
    for i in range(5):
        store.record(result([1, 2], cpu=float(i)))
    assert store.cpu("1:1") == [2.0, 3.0, 4.0]
    assert store.memory("2:2") == [100.0] * 3
    store.record(result([1], cpu=9.0))
    assert store.cpu("2:2") == [] and store.tracked() == 1
    assert list(store.total_cpu)[-1] == 9.0
    assert list(store.mem_used)[-1] == 0.5
