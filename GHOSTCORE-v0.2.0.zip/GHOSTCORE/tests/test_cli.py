import contextlib
import io

from ghostcore import cli
from ghostcore.core.protocol import GCPEvent
from ghostcore.core.store import EventStore


def test_parse_age():
    assert cli._parse_age("90") == 90 and cli._parse_age("2m") == 120
    assert cli._parse_age("1h") == 3600 and cli._parse_age("1d") == 86400


def test_watch_once_prints_table():
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        assert cli.main(["watch", "--once", "--top", "3"]) == 0
    assert "PID" in out.getvalue() and "NAME" in out.getvalue()


def test_history_filters_by_prefix(tmp_path):
    path = tmp_path / "h.db"
    with EventStore(path) as store:
        store.append_many([GCPEvent("alert.zombie", {"n": 1}, 1),
                           GCPEvent("system.sample", {}, 2)])
    buffer = io.BytesIO()
    wrapper = io.TextIOWrapper(buffer, encoding="utf-8")
    with contextlib.redirect_stdout(wrapper):
        assert cli.main(["history", "--db", str(path), "--type", "alert."]) == 0
        wrapper.flush()
    lines = buffer.getvalue().splitlines()
    assert len(lines) == 1 and b"alert.zombie" in lines[0]


def test_record_requires_a_sink():
    assert cli.main(["record"]) == 2
