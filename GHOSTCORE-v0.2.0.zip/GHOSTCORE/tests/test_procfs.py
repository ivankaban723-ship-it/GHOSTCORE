from ghostcore.collectors.procfs import ProcfsCollector, process_age_seconds

from conftest import write_proc, write_system


def test_collects_current_process():
    processes = ProcfsCollector().collect()
    assert processes
    assert all(process.pid > 0 for process in processes)
    assert all(process.start_ticks >= 0 for process in processes)


def test_node_ids_are_unique_for_snapshot():
    processes = ProcfsCollector().collect()
    node_ids = [process.node_id for process in processes]
    assert len(node_ids) == len(set(node_ids))


def test_parses_fake_proc_fields(fake_proc):
    write_proc(fake_proc, 10, name="my (weird) name", state="R", ppid=1,
               utime=30, stime=12, threads=4, start=777, rss_kib=2048, uid=1234)
    (snap,) = ProcfsCollector(fake_proc).collect()
    assert snap.name == "my (weird) name"       # parens in comm
    assert (snap.pid, snap.ppid, snap.state) == (10, 1, "R")
    assert snap.cpu_ticks == 42
    assert snap.num_threads == 4
    assert snap.start_ticks == 777 and snap.node_id == "10:777"
    assert snap.memory_bytes == 2048 * 1024
    assert snap.uid == 1234


def test_skips_broken_and_non_numeric_entries(fake_proc):
    write_proc(fake_proc, 11)
    (fake_proc / "12").mkdir()                     # no stat file
    (fake_proc / "13").mkdir()
    (fake_proc / "13" / "stat").write_text("garbage")
    (fake_proc / "14").mkdir()
    (fake_proc / "14" / "stat").write_text("14 (x) S 1 2 3")   # too short
    (fake_proc / "self").mkdir()
    assert [p.pid for p in ProcfsCollector(fake_proc).collect()] == [11]


def test_missing_status_still_collects(fake_proc):
    write_proc(fake_proc, 15)
    (fake_proc / "15" / "status").unlink()
    (snap,) = ProcfsCollector(fake_proc).collect()
    assert snap.memory_bytes == 0 and snap.uid == -1


def test_missing_proc_root_is_empty(tmp_path):
    assert ProcfsCollector(tmp_path / "nope").collect() == []


def test_cmdline_on_demand_and_not_in_events(fake_proc):
    write_proc(fake_proc, 20, cmdline=b"/bin/tool\0--token=SECRET\0")
    collector = ProcfsCollector(fake_proc)
    assert collector.read_cmdline(20) == "/bin/tool --token=SECRET"
    assert collector.read_cmdline(999) == ""
    payloads = [e.payload for e in collector.collect_events()]
    assert "SECRET" not in repr(payloads)           # never leaves the process


def test_system_stats(fake_proc):
    stats = ProcfsCollector(fake_proc).system_stats(process_count=3)
    assert (stats.load1, stats.load5, stats.load15) == (0.5, 0.4, 0.3)
    assert stats.uptime_s == 1000.5 and stats.process_count == 3
    assert stats.mem_total_bytes == 8_000_000 * 1024
    assert abs(stats.mem_used_ratio - 0.75) < 1e-9


def test_system_stats_unavailable(tmp_path):
    assert ProcfsCollector(tmp_path).system_stats() is None


def test_process_age(fake_proc):
    write_proc(fake_proc, 30, start=20000)         # 200 s after boot at 100 Hz
    (snap,) = ProcfsCollector(fake_proc).collect()
    assert process_age_seconds(snap, uptime_s=1000.0, clock_ticks=100) == 800.0
    assert process_age_seconds(snap, uptime_s=1.0, clock_ticks=100) == 0.0
