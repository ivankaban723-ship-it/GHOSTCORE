import sqlite3

import pytest

from ghostcore.core.protocol import EventType, GCPEvent
from ghostcore.core.store import EventStore


def sample(node, ts, cpu=1.0, mem=10):
    return GCPEvent(EventType.PROCESS_SAMPLE,
                    {"node_id": node, "cpu_percent": cpu, "memory_bytes": mem}, ts)


def test_append_query_roundtrip_and_ordering():
    with EventStore() as store:
        store.append_many([sample("a", 30), sample("a", 10), GCPEvent("system.sample", {"x": 1}, 20)])
        assert store.count() == 3
        assert [e.timestamp_ns for e in store.query()] == [10, 20, 30]
        assert [e.timestamp_ns for e in store.query(newest_first=True, limit=2)] == [30, 20]
        assert store.query(types=["system.sample"])[0].payload == {"x": 1}
        assert store.query(types=[]) == []


def test_filters_by_time_node_and_prefix():
    with EventStore() as store:
        store.append_many([sample("a", 1), sample("b", 2), GCPEvent("alert.zombie", {}, 3),
                           GCPEvent("process.exited", {"node_id": "a"}, 4)])
        assert len(store.query(node_id="a")) == 2
        assert len(store.query(since_ns=2, until_ns=3)) == 2
        assert {e.event_type for e in store.query(type_prefixes=["process."])} == {
            "process.sample", "process.exited"}
        assert len(store.query(type_prefixes=["alert.", "process.ex"])) == 2
        assert store.query(type_prefixes=["pro_ess."]) == []      # '_' is not a wildcard
        assert store.query(type_prefixes=["%"]) == []             # nor is '%'


def test_series_extracts_cpu_and_memory():
    with EventStore() as store:
        store.append_many([sample("a", 1, 5.5, 100), sample("a", 2, 7.0, 200), sample("b", 3)])
        assert store.series("a") == [(1, 5.5, 100), (2, 7.0, 200)]
        assert store.series("a", since_ns=2) == [(2, 7.0, 200)]


def test_prune_by_age_and_rows():
    with EventStore() as store:
        store.append_many([sample("a", t * 10**9) for t in range(1, 11)])
        assert store.prune(max_age_s=5, now_ns=10 * 10**9) == 4   # keep ts >= 5 s
        assert store.count() == 6
        assert store.prune(max_rows=3) == 3
        assert [e.timestamp_ns // 10**9 for e in store.query()] == [8, 9, 10]
        assert store.prune(max_rows=100) == 0


def test_persists_on_disk_and_closes_safely(tmp_path):
    path = tmp_path / "sub" / "h.db"
    store = EventStore(path)
    store.append(sample("a", 1))
    store.close()
    store.append(sample("a", 2))          # no-op after close, must not raise
    store.close()
    with EventStore(path) as again:
        assert again.count() == 1


def test_rejects_newer_schema(tmp_path):
    path = tmp_path / "future.db"
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA user_version=99")
    conn.commit()
    conn.close()
    with pytest.raises(RuntimeError, match="newer"):
        EventStore(path)
