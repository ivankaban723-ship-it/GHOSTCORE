from ghostcore.core.bus import EventBus
from ghostcore.core.protocol import GCPEvent


def ev(t):
    return GCPEvent(t, {}, 1)


def test_prefix_filter_and_unsubscribe():
    bus, got = EventBus(), []
    unsub = bus.subscribe(lambda e: got.append(e.event_type), prefixes=["process."])
    bus.publish_many([ev("process.a"), ev("system.b"), ev("process.c")])
    assert got == ["process.a", "process.c"]
    unsub()
    bus.publish(ev("process.d"))
    assert got == ["process.a", "process.c"]


def test_batch_subscriber_gets_whole_batch():
    bus, batches = EventBus(), []
    bus.subscribe_batch(lambda events: batches.append(len(events)))
    bus.publish_many([ev("a"), ev("b"), ev("c")])
    bus.publish_many([])
    assert batches == [3]


def test_failing_subscriber_is_isolated():
    bus, got = EventBus(), []

    def boom(_):
        raise RuntimeError("x")

    bus.subscribe(boom)
    bus.subscribe_batch(lambda events: boom(events))
    bus.subscribe(lambda e: got.append(e))
    bus.publish(ev("a"))
    assert len(got) == 1 and bus.errors == 2
