from pathlib import Path

import pytest

from ghostcore.collectors.procfs import ProcessSnapshot
from ghostcore.core.monitor import PollResult
from ghostcore.core.protocol import GCPEvent
from ghostcore.plugins.api import GhostPlugin
from ghostcore.plugins.manager import MAX_CONSECUTIVE_FAILURES, PluginManager

EXAMPLES = Path(__file__).resolve().parent.parent / "examples" / "plugins"


class Good(GhostPlugin):
    name = "good"

    def collect(self):
        return [GCPEvent("custom.ping", {}, 1)]


def test_register_validates_names_and_duplicates():
    manager = PluginManager()
    with pytest.raises(ValueError):
        manager.register(GhostPlugin())             # unnamed
    manager.register(Good())
    with pytest.raises(ValueError, match="already"):
        manager.register(Good())
    assert manager.list_plugins()[0]["name"] == "good"


def test_permissions_unknown_and_denied():
    class Greedy(GhostPlugin):
        name = "greedy"
        permissions = ("net",)

    class Weird(GhostPlugin):
        name = "weird"
        permissions = ("root",)

    manager = PluginManager()
    with pytest.raises(PermissionError, match="not allowed"):
        manager.register(Greedy())
    with pytest.raises(PermissionError, match="unknown"):
        manager.register(Weird())
    PluginManager(allowed_permissions={"net"}).register(Greedy())


def test_reserved_namespaces_and_bad_events_are_dropped():
    class Spoofer(GhostPlugin):
        name = "spoofer"

        def collect(self):
            return [GCPEvent("process.exited", {"node_id": "1:1"}, 1),
                    GCPEvent("system.sample", {}, 1), "junk", GCPEvent("ok.event", {}, 1)]

    manager = PluginManager()
    manager.register(Spoofer())
    assert [e.event_type for e in manager.collect_all()] == ["ok.event"]
    assert manager.dropped_events == 3


def test_failing_plugin_is_isolated_then_disabled():
    class Bad(GhostPlugin):
        name = "bad"

        def collect(self):
            raise RuntimeError("boom")

    manager = PluginManager()
    manager.register(Bad())
    manager.register(Good())
    for _ in range(MAX_CONSECUTIVE_FAILURES + 2):
        events = manager.collect_all()
        assert [e.event_type for e in events] == ["custom.ping"]   # Good keeps working
    assert any("disabled" in r for r in manager.rejected)
    assert {p["name"]: p["enabled"] for p in manager.list_plugins()} == {"bad": False, "good": True}


def test_start_failure_rolls_back_and_stop_all_survives_errors():
    log = []

    class A(GhostPlugin):
        name = "a"
        def start(self): log.append("start a")
        def stop(self): log.append("stop a")

    class B(GhostPlugin):
        name = "b"
        def start(self): raise RuntimeError("nope")

    manager = PluginManager()
    manager.register(A())
    manager.register(B())
    with pytest.raises(RuntimeError):
        manager.start_all()
    assert log == ["start a", "stop a"]

    class C(GhostPlugin):
        name = "c"
        def stop(self): raise RuntimeError("x")

    manager.register(C())
    manager.stop_all()                              # must not raise


def test_discovery_loads_example_and_reports_bad_files(tmp_path):
    (tmp_path / "broken.py").write_text("raise RuntimeError('bad import')\n")
    (tmp_path / "_private.py").write_text("raise RuntimeError('never imported')\n")
    (tmp_path / "greedy.py").write_text(
        "from ghostcore.plugins.api import GhostPlugin\n"
        "class G(GhostPlugin):\n    name='g'\n    permissions=('net',)\n")
    (tmp_path / "zombie_watch.py").write_text((EXAMPLES / "zombie_watch.py").read_text())

    manager = PluginManager()
    assert manager.discover(tmp_path) == ["zombie-watch"]
    reasons = " | ".join(manager.rejected)
    assert "broken.py" in reasons and "greedy.py" in reasons and "_private" not in reasons
    other = PluginManager()
    assert other.discover(tmp_path / "missing") == []
    assert "not a directory" in other.rejected[0]


def test_example_zombie_plugin_reports_each_zombie_once():
    manager = PluginManager()
    manager.discover(EXAMPLES)
    manager.start_all()

    def poll(*snaps):
        return PollResult(7, 1.0, tuple(snaps))

    z = ProcessSnapshot(9, 1, "defunct", "Z", 0, 9)
    ok = ProcessSnapshot(8, 1, "fine", "S", 0, 8)
    first = manager.dispatch_poll(poll(ok, z))
    assert [(e.event_type, e.payload["pid"]) for e in first] == [("alert.zombie", 9)]
    assert manager.dispatch_poll(poll(ok, z)) == []                  # same zombie: silent
    assert manager.dispatch_poll(poll(ok)) == []
    assert len(manager.dispatch_poll(poll(ok, z))) == 1              # came back: new alert
