import math

import numpy as np

from ghostcore.collectors.procfs import ProcessSnapshot
from ghostcore.core.layout import ForceLayout, radial_layout


def P(pid, ppid, name="p"):
    return ProcessSnapshot(pid, ppid, name, "S", 0, pid)


def test_radial_single_root_at_origin_and_all_placed():
    procs = [P(1, 0, "init"), P(2, 1, "a"), P(3, 1, "b"), P(4, 2, "c")]
    pos = radial_layout(procs)
    assert set(pos) == {p.node_id for p in procs}
    assert pos["1:1"] == (0.0, 0.0)
    r = lambda nid: math.hypot(*pos[nid])
    assert abs(r("2:2") - 175) < 1e-6 and abs(r("4:4") - 350) < 1e-6


def test_radial_forest_cycles_and_self_parent_are_safe():
    procs = [P(1, 0), P(5, 0), P(10, 11), P(11, 10), P(12, 12)]   # cycle + self-parent
    pos = radial_layout(procs)
    assert set(pos) == {p.node_id for p in procs}
    assert all(math.isfinite(x) and math.isfinite(y) for x, y in pos.values())


def test_radial_empty_and_deterministic():
    assert radial_layout([]) == {}
    procs = [P(1, 0), P(2, 1), P(3, 1)]
    assert radial_layout(procs) == radial_layout(list(reversed(procs)))


def settle(layout, max_steps=800):
    layout.reheat()
    for _ in range(max_steps):
        if not layout.step():
            break
    return layout.positions()


def test_force_chain_converges_to_link_distance():
    ids = [str(i) for i in range(8)]
    edges = [(str(i), str(i + 1)) for i in range(7)]
    layout = ForceLayout()
    layout.set_graph(ids, edges)
    pos = settle(layout)
    assert layout.asleep
    lengths = [math.dist(pos[a], pos[b]) for a, b in edges]
    assert all(0.6 * layout.link_distance < l < 1.6 * layout.link_distance for l in lengths)
    assert all(math.isfinite(v) for p in pos.values() for v in p)


def test_force_separates_coincident_nodes_and_handles_tiny_graphs():
    layout = ForceLayout()
    layout.set_graph(["a", "b", "c"], [("a", "b"), ("a", "c")],
                     {"a": (0, 0), "b": (0, 0), "c": (0, 0)})
    pos = settle(layout)
    assert math.dist(pos["b"], pos["c"]) > 20
    empty = ForceLayout()
    empty.set_graph([], [])
    assert empty.step() is False and empty.positions() == {}
    one = ForceLayout()
    one.set_graph(["x"], [], {"x": (50, 50)})
    one.reheat()
    assert one.step() in (True, False) and "x" in one.positions()


def test_force_keeps_existing_positions_and_spawns_near_parent():
    layout = ForceLayout()
    layout.set_graph(["a", "b"], [("a", "b")], {"a": (0, 0), "b": (80, 0)})
    before = layout.positions()
    layout.set_graph(["a", "b", "c"], [("a", "b"), ("b", "c")])
    after = layout.positions()
    assert after["a"] == before["a"] and after["b"] == before["b"]
    assert math.dist(after["c"], after["b"]) <= 25.0 + 1e-6


def test_force_pinned_node_stays_put_and_wakes_simulation():
    layout = ForceLayout()
    ids = ["a", "b", "c"]
    layout.set_graph(ids, [("a", "b"), ("a", "c")], {"a": (0, 0), "b": (80, 0), "c": (0, 80)})
    settle(layout)
    assert layout.asleep
    layout.pin("b", 300.0, 300.0)
    assert not layout.asleep
    for _ in range(100):
        layout.step()
    pos = layout.positions()
    assert pos["b"] == (300.0, 300.0)
    assert math.dist(pos["a"], pos["b"]) < 250        # parent was dragged along
    layout.unpin("b")
    layout.pin("ghost", 1, 1)                          # unknown ids are ignored
    assert "ghost" not in layout.positions()


def test_force_scales_to_hundreds_of_nodes():
    rng = np.random.default_rng(3)
    n = 300
    ids = [str(i) for i in range(n)]
    edges = [(str(int(rng.integers(0, i))), str(i)) for i in range(1, n)]
    layout = ForceLayout()
    layout.set_graph(ids, edges)
    pos = settle(layout)
    arr = np.array(list(pos.values()))
    assert np.isfinite(arr).all() and np.abs(arr).max() < 3000
