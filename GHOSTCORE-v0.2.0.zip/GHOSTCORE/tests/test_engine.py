import os
import tempfile
import threading
import time

from ghostcore.collectors.procfs import ProcfsCollector
from ghostcore.core.config import AppConfig
from ghostcore.core.engine import Engine, build_engine
from ghostcore.core.store import EventStore
from ghostcore.core.transport import stream_events

from conftest import write_proc


def test_tick_publishes_to_bus_and_store(fake_proc):
    write_proc(fake_proc, 1)
    store = EventStore()
    engine = Engine(collector=ProcfsCollector(fake_proc), store=store)
    seen = []
    engine.bus.subscribe(lambda e: seen.append(e.event_type))
    result = engine.tick()
    assert len(result.snapshots) == 1
    assert "process.snapshot" in seen and "system.sample" in seen
    assert store.count() == len(seen)
    engine.close()
    engine.close()                                   # idempotent


def test_build_engine_reports_non_fatal_problems(tmp_path):
    config = AppConfig(db_path=str(tmp_path), socket_path=str(tmp_path),
                       plugins_dir=str(tmp_path / "missing"))
    engine, warnings = build_engine(config)          # db path is a directory, etc.
    text = " | ".join(warnings)
    assert "history disabled" in text and "socket disabled" in text and "not a directory" in text
    assert engine.tick().snapshots                   # still works


def test_end_to_end_socket_and_db(tmp_path):
    sock = os.path.join(tempfile.mkdtemp(prefix="gc"), "e.sock")
    config = AppConfig(db_path=str(tmp_path / "h.db"), socket_path=sock)
    engine, warnings = build_engine(config)
    assert warnings == []
    engine.tick()                                    # baseline before the client joins

    got = []

    def client():
        for event in stream_events(sock, timeout=5):
            got.append(event)
            if any(e.event_type == "system.sample" for e in got):
                return

    t = threading.Thread(target=client)
    t.start()
    end = time.time() + 3
    while engine.server.client_count < 1 and time.time() < end:
        time.sleep(0.01)
    engine.tick()
    t.join(timeout=5)
    engine.close()
    kinds = {e.event_type for e in got}
    assert "process.snapshot" in kinds               # replayed on connect
    assert "system.sample" in kinds                  # live
    assert not os.path.exists(sock)
    with EventStore(tmp_path / "h.db") as store:
        assert store.count() > 0


def test_run_forever_stops_on_event(fake_proc):
    write_proc(fake_proc, 1)
    engine = Engine(collector=ProcfsCollector(fake_proc))
    stop = threading.Event()
    t = threading.Thread(target=engine.run_forever, args=(0.01, stop))
    t.start()
    time.sleep(0.1)
    stop.set()
    t.join(timeout=2)
    assert not t.is_alive()
    engine.close()
