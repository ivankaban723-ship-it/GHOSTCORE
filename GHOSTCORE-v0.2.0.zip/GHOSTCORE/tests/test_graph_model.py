from ghostcore.collectors.procfs import ProcessSnapshot
from ghostcore.core.graph_model import (
    ancestry_chain, format_bytes, format_duration, matches, node_radius,
    state_color, top_by_cpu, topology_signature,
)


def P(pid, ppid, name="p", state="S", mem=0):
    return ProcessSnapshot(pid, ppid, name, state, mem, pid)


def test_node_radius_is_monotonic_and_bounded():
    sizes = [node_radius(m) for m in (0, 1 << 20, 100 << 20, 1 << 30, 64 << 30)]
    assert sizes == sorted(sizes)
    assert sizes[0] == 6.0 and sizes[-1] == 18.0
    assert node_radius(-5) == 6.0


def test_state_colors():
    assert state_color("Z") != state_color("R")
    assert state_color("?") == state_color("weird")


def test_matches_name_pid_and_state():
    s = P(1234, 1, "Firefox", "Z")
    assert matches("", s) and matches("fire", s) and matches("234", s)
    assert not matches("chrome", s)
    assert matches("state:z", s) and not matches("state:r", s)
    assert not matches("state:", s)


def test_ancestry_chain_and_cycles():
    procs = {p.node_id: p for p in [P(1, 0), P(2, 1), P(3, 2)]}
    assert ancestry_chain("3:3", procs) == ["3:3", "2:2", "1:1"]
    assert ancestry_chain("nope", procs) == []
    cyc = {p.node_id: p for p in [P(1, 2), P(2, 1), P(3, 3)]}
    assert sorted(ancestry_chain("1:1", cyc)) == ["1:1", "2:2"]
    assert ancestry_chain("3:3", cyc) == ["3:3"]


def test_top_by_cpu_orders_and_limits():
    procs = [P(1, 0, mem=5), P(2, 1, mem=9), P(3, 1)]
    ranked = top_by_cpu(procs, {"3:3": 50.0, "1:1": 10.0}, count=2)
    assert [s.pid for s, _ in ranked] == [3, 1]
    assert top_by_cpu(procs, {}, 3)[0][0].pid == 2      # tie -> bigger memory first


def test_topology_signature_ignores_non_structural_changes():
    a = [P(1, 0, state="S"), P(2, 1)]
    b = [P(1, 0, state="R", mem=10), P(2, 1)]
    assert topology_signature(a) == topology_signature(b)
    assert topology_signature(a) != topology_signature([P(1, 0), P(2, 0)])


def test_formatters():
    assert format_bytes(0) == "0 B" and format_bytes(1536) == "1.5 KiB"
    assert format_bytes(5 * 1024 ** 3) == "5.0 GiB"
    assert format_duration(5) == "5s" and format_duration(125) == "2m 5s"
    assert format_duration(3700) == "1h 1m" and format_duration(90000) == "1d 1h"
