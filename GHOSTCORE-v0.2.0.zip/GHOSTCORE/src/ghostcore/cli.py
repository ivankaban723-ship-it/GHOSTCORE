"""Headless GHOSTCORE command line: ``python -m ghostcore.cli <command>``."""

from __future__ import annotations

import argparse
import signal
import sys
import threading
import time
from typing import Sequence

from ghostcore.core.config import AppConfig
from ghostcore.core.engine import Engine, build_engine
from ghostcore.core.graph_model import format_bytes, top_by_cpu
from ghostcore.core.store import EventStore
from ghostcore.core.transport import stream_events


def _parse_age(text: str) -> float:
    """'90', '30s', '15m', '2h', '1d' -> seconds."""
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    text = text.strip().lower()
    if text and text[-1] in units:
        return float(text[:-1]) * units[text[-1]]
    return float(text)


def cmd_watch(args: argparse.Namespace) -> int:
    engine = Engine()
    engine.start()
    try:
        while True:
            result = engine.tick()
            lines = []
            if result.system:
                s = result.system
                lines.append(
                    f"load {s.load1:.2f} {s.load5:.2f} {s.load15:.2f}  "
                    f"mem {s.mem_used_ratio * 100:.0f}%  procs {s.process_count}"
                )
            lines.append(f"{'PID':>7} {'CPU%':>6} {'RSS':>10} S  NAME")
            for snap, cpu in top_by_cpu(result.snapshots, result.cpu_percent, args.top):
                lines.append(
                    f"{snap.pid:>7} {cpu:>6.1f} {format_bytes(snap.memory_bytes):>10} "
                    f"{snap.state}  {snap.name}"
                )
            if args.once:
                print("\n".join(lines))
                return 0
            sys.stdout.write("\x1b[2J\x1b[H" + "\n".join(lines) + "\n")
            sys.stdout.flush()
            time.sleep(args.interval)
    except KeyboardInterrupt:
        return 0
    finally:
        engine.close()


def cmd_record(args: argparse.Namespace) -> int:
    if not args.db and not args.socket:
        print("record: give --db and/or --socket", file=sys.stderr)
        return 2
    config = AppConfig(
        interval_ms=int(args.interval * 1000),
        db_path=args.db,
        socket_path=args.socket,
        plugins_dir=args.plugins_dir,
    )
    engine, warnings = build_engine(config)
    for warning in warnings:
        print(f"warning: {warning}", file=sys.stderr)
    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    print("recording, Ctrl+C to stop", file=sys.stderr)
    try:
        engine.run_forever(config.interval_ms / 1000, stop)
    finally:
        engine.close()
    return 0


def cmd_tail(args: argparse.Namespace) -> int:
    try:
        for event in stream_events(args.socket):
            if args.type and not event.event_type.startswith(tuple(args.type)):
                continue
            sys.stdout.buffer.write(event.encode())
            sys.stdout.buffer.flush()
    except (KeyboardInterrupt, BrokenPipeError):
        return 0
    except OSError as exc:
        print(f"tail: {exc}", file=sys.stderr)
        return 1
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    with EventStore(args.db) as store:
        since = time.time_ns() - int(_parse_age(args.since) * 1e9) if args.since else None
        events = store.query(
            since_ns=since,
            type_prefixes=args.type or None,
            node_id=args.node,
            limit=args.limit,
            newest_first=True,
        )
        for event in reversed(events):
            sys.stdout.buffer.write(event.encode())
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ghostcore-cli", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    watch = sub.add_parser("watch", help="live top-style view in the terminal")
    watch.add_argument("--interval", type=float, default=1.0)
    watch.add_argument("--top", type=int, default=15)
    watch.add_argument("--once", action="store_true", help="print one sample and exit")
    watch.set_defaults(func=cmd_watch)

    record = sub.add_parser("record", help="collect headlessly into SQLite and/or a socket")
    record.add_argument("--db")
    record.add_argument("--socket")
    record.add_argument("--plugins-dir")
    record.add_argument("--interval", type=float, default=1.5)
    record.set_defaults(func=cmd_record)

    tail = sub.add_parser("tail", help="print the GCP stream of a running instance")
    tail.add_argument("--socket", required=True)
    tail.add_argument("--type", action="append", help="type prefix filter, repeatable")
    tail.set_defaults(func=cmd_tail)

    hist = sub.add_parser("history", help="query recorded events (JSON Lines)")
    hist.add_argument("--db", required=True)
    hist.add_argument("--since", help="e.g. 30s, 15m, 2h, 1d")
    hist.add_argument("--type", action="append", help="type prefix filter, repeatable")
    hist.add_argument("--node")
    hist.add_argument("--limit", type=int, default=1000)
    hist.set_defaults(func=cmd_history)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
