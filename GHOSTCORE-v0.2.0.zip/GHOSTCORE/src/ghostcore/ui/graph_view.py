"""Interactive, incrementally updated process graph for GHOSTCORE.

Nodes are coloured by process state, sized by memory and ringed by CPU load.
New processes flash in next to their parent; exited ones linger for a moment as
red "ghosts". Two layouts are available: an animated radial tree and a live
force simulation (``L`` toggles, ``R`` re-lays out, ``F`` fits the view).
"""

from __future__ import annotations

import math
import random
from typing import Iterable, Mapping

from PySide6.QtCore import QLineF, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QGraphicsEllipseItem,
    QGraphicsItem,
    QGraphicsLineItem,
    QGraphicsScene,
    QGraphicsSimpleTextItem,
    QGraphicsView,
)

from ghostcore.collectors.procfs import ProcessSnapshot
from ghostcore.core.graph_model import (
    ancestry_chain,
    matches,
    node_radius,
    state_color,
    topology_signature,
)
from ghostcore.core.layout import ForceLayout, radial_layout

BACKGROUND = QColor("#0B0F19")
NODE_SELECTED = QColor("#22D3EE")
EDGE_COLOR = QColor("#35415C")
EDGE_HIGHLIGHT = QColor("#22D3EE")
TEXT_COLOR = QColor("#E2E8F0")
RING_COLOR = QColor("#141B2D")

ANIM_INTERVAL_MS = 33
FLASH_DECAY = 0.05
GHOST_TTL_MS = 2500
HOT_CPU_PERCENT = 8.0
SCENE_EXTENT = 60000.0
MIN_ZOOM, MAX_ZOOM = 0.03, 6.0


def _mix(a: QColor, b: QColor, t: float) -> QColor:
    t = max(0.0, min(1.0, t))
    return QColor(
        int(a.red() * (1 - t) + b.red() * t),
        int(a.green() * (1 - t) + b.green() * t),
        int(a.blue() * (1 - t) + b.blue() * t),
    )


class ProcessEdge(QGraphicsLineItem):
    """A parent-child edge that follows its nodes."""

    def __init__(self, source: "ProcessNode", target: "ProcessNode") -> None:
        super().__init__()
        self.source = source
        self.target = target
        self.highlighted = False
        self.setZValue(-2)
        self.setPen(QPen(EDGE_COLOR, 1.3))
        source.edges.append(self)
        target.edges.append(self)
        self.update_position()

    def update_position(self) -> None:
        self.setLine(QLineF(self.source.pos(), self.target.pos()))

    def set_highlight(self, on: bool) -> None:
        if on == self.highlighted:
            return
        self.highlighted = on
        self.setZValue(-1 if on else -2)
        self.setPen(QPen(EDGE_HIGHLIGHT if on else EDGE_COLOR, 2.6 if on else 1.3))

    def refresh_dim(self) -> None:
        dim = self.source.dimmed or self.target.dimmed
        self.setOpacity(0.08 if dim else 1.0)


class ProcessNode(QGraphicsEllipseItem):
    def __init__(self, process: ProcessSnapshot, cpu: float = 0.0) -> None:
        radius = node_radius(process.memory_bytes)
        super().__init__(-radius, -radius, radius * 2, radius * 2)
        self.process = process
        self.radius = radius
        self.cpu = cpu
        self.edges: list[ProcessEdge] = []
        self.flash = 0.0          # 1.0 right after spawning, fades to 0
        self.ghost = False        # process exited, fading out
        self.ghost_ms = 0
        self.dimmed = False       # filtered out
        self.dragging = False
        self.manual = False       # user placed it by hand (radial layout)
        self.hovering = False

        self.label = QGraphicsSimpleTextItem("", self)
        self.label.setBrush(QBrush(TEXT_COLOR))
        self.label.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIgnoresTransformations, True)
        self.label.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self.label.setPos(15, -10)

        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.setAcceptHoverEvents(True)
        self._refresh_text()
        self.restyle()

    # ------------------------------------------------------------------ #
    def _refresh_text(self) -> None:
        p = self.process
        self.label.setText(f"{p.name} [{p.pid}]")
        self.setToolTip(
            f"{p.name}\nPID: {p.pid}   PPID: {p.ppid}\n"
            f"State: {p.state}   Threads: {p.num_threads}\n"
            f"CPU: {self.cpu:.1f}%   RSS: {p.memory_bytes / 1048576:.1f} MiB\n"
            "Click to inspect · drag to reposition"
        )

    def update_process(self, process: ProcessSnapshot, cpu: float) -> None:
        self.process = process
        self.cpu = cpu
        radius = node_radius(process.memory_bytes)
        if abs(radius - self.radius) > 0.25:
            self.radius = radius
            self.setRect(-radius, -radius, radius * 2, radius * 2)
        self._refresh_text()
        self.restyle()

    def mark_ghost(self) -> None:
        self.ghost = True
        self.ghost_ms = GHOST_TTL_MS
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, False)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, False)
        self.restyle()

    def restyle(self) -> None:
        if self.ghost:
            fade = max(0.0, min(1.0, self.ghost_ms / GHOST_TTL_MS))
            fill = QColor("#F43F5E")
            pen_color = QColor("#FDA4AF")
            self.setOpacity(0.2 + 0.6 * fade)
        else:
            base = QColor(state_color(self.process.state))
            fill = _mix(base, QColor("#ECFDF5"), self.flash * 0.85)
            pen_color = _mix(base, QColor("#FFFFFF"), 0.35)
            self.setOpacity(0.14 if self.dimmed else 1.0)

        width = 1.4 + min(self.cpu / 20.0, 3.6)
        selected = self.isSelected() and not self.ghost
        if selected:
            fill = NODE_SELECTED
            pen_color = QColor("#A5F3FC")
            width = max(width, 2.6)
        self.setBrush(QBrush(fill))
        self.setPen(QPen(pen_color, width))

        show_label = not self.dimmed and (
            selected or self.hovering or self.ghost or self.cpu >= HOT_CPU_PERCENT
        )
        self.label.setVisible(show_label)

    # ------------------------------------------------------------------ #
    def itemChange(self, change, value):
        result = super().itemChange(change, value)
        if change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            for edge in self.edges:
                edge.update_position()
        elif change == QGraphicsItem.GraphicsItemChange.ItemSelectedHasChanged:
            self.restyle()
        return result

    def hoverEnterEvent(self, event) -> None:
        self.hovering = True
        self.restyle()
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:
        self.hovering = False
        self.restyle()
        super().hoverLeaveEvent(event)


class ProcessGraphView(QGraphicsView):
    process_selected = Signal(object)
    selection_cleared = Signal()
    layout_mode_changed = Signal(str)

    def __init__(self, parent=None) -> None:
        self.graph_scene = QGraphicsScene()
        super().__init__(self.graph_scene, parent)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumSize(600, 400)
        # A huge fixed scene acts as an infinite canvas; scrollbars are hidden.
        self.graph_scene.setSceneRect(-SCENE_EXTENT, -SCENE_EXTENT, 2 * SCENE_EXTENT, 2 * SCENE_EXTENT)
        self.graph_scene.selectionChanged.connect(self._selection_changed)

        self._nodes: dict[str, ProcessNode] = {}
        self._ghosts: dict[str, ProcessNode] = {}
        self._edges: dict[tuple[str, str], ProcessEdge] = {}
        self._processes: dict[str, ProcessSnapshot] = {}
        self._topology: frozenset | None = None
        self._targets: dict[str, tuple[float, float]] = {}
        self._mode = "radial"
        self._force = ForceLayout()
        self._ring_base = 0.0
        self._filter = ""
        self._selected_id: str | None = None
        self._drag_node: ProcessNode | None = None
        self._rng = random.Random(11)

        self._anim = QTimer(self)
        self._anim.setInterval(ANIM_INTERVAL_MS)
        self._anim.timeout.connect(self._tick)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    @property
    def layout_mode(self) -> str:
        return self._mode

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    def set_layout_mode(self, mode: str) -> None:
        if mode not in ("radial", "force"):
            return
        if mode == "force" and len(self._nodes) > ForceLayout.MAX_NODES:
            mode = "radial"   # too many nodes for interactive physics
        changed = mode != self._mode
        self._mode = mode
        for node in self._nodes.values():
            node.manual = False
        self._relayout()
        self._ensure_anim()
        self.viewport().update()
        if changed:
            self.layout_mode_changed.emit(mode)

    def toggle_layout(self) -> None:
        self.set_layout_mode("force" if self._mode == "radial" else "radial")

    def relayout(self) -> None:
        for node in self._nodes.values():
            node.manual = False
        self._relayout(reheat=1.0)
        self._ensure_anim()

    def set_filter(self, text: str) -> None:
        self._filter = text
        self._apply_filter()

    def select_node(self, node_id: str) -> None:
        node = self._nodes.get(node_id)
        if node is None:
            return
        self.graph_scene.clearSelection()
        node.setSelected(True)
        self.centerOn(node)

    def fit_graph(self) -> None:
        if not self._nodes:
            return
        xs = [n.x() for n in self._nodes.values()]
        ys = [n.y() for n in self._nodes.values()]
        margin = 160.0
        rect = QRectF(
            min(xs) - margin,
            min(ys) - margin,
            max(xs) - min(xs) + 2 * margin,
            max(ys) - min(ys) + 2 * margin,
        )
        self.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)

    def update_processes(
        self,
        processes: Iterable[ProcessSnapshot],
        cpu_percent: Mapping[str, float] | None = None,
    ) -> None:
        processes = list(processes)
        cpu = cpu_percent or {}
        current = {p.node_id: p for p in processes}
        by_pid = {p.pid: p for p in processes}
        first_render = not self._nodes and not self._ghosts and self._topology is None
        self._processes = current
        changed = False

        # Exits: keep the node around as a fading ghost.
        for node_id in [n for n in self._nodes if n not in current]:
            node = self._nodes.pop(node_id)
            node.mark_ghost()
            self._ghosts[node_id] = node
            changed = True

        # Spawns and updates.
        for process in processes:
            node = self._nodes.get(process.node_id)
            value = cpu.get(process.node_id, 0.0)
            if node is None:
                node = ProcessNode(process, value)
                node.flash = 0.0 if first_render else 1.0
                origin = self._spawn_origin(process, by_pid)
                node.setPos(*origin)
                self.graph_scene.addItem(node)
                self._nodes[process.node_id] = node
                changed = True
            else:
                node.update_process(process, value)

        self._sync_edges(processes, by_pid)

        signature = topology_signature(processes)
        topology_changed = signature != self._topology
        self._topology = signature
        if topology_changed or changed:
            self._relayout(first=first_render)
        self._apply_filter()
        if self._selected_id is not None:
            self._update_highlight(self._selected_id)
        if first_render:
            self.fit_graph()
        self._ensure_anim()

    # ------------------------------------------------------------------ #
    # Graph maintenance
    # ------------------------------------------------------------------ #
    def _spawn_origin(
        self, process: ProcessSnapshot, by_pid: Mapping[int, ProcessSnapshot]
    ) -> tuple[float, float]:
        parent = by_pid.get(process.ppid)
        parent_node = self._nodes.get(parent.node_id) if parent is not None else None
        if parent_node is None:
            return (0.0, 0.0)
        angle = self._rng.uniform(0, 2 * math.pi)
        return (parent_node.x() + 12 * math.cos(angle), parent_node.y() + 12 * math.sin(angle))

    def _sync_edges(
        self, processes: list[ProcessSnapshot], by_pid: Mapping[int, ProcessSnapshot]
    ) -> None:
        desired: set[tuple[str, str]] = set()
        for process in processes:
            parent = by_pid.get(process.ppid)
            if parent is not None and parent.pid != process.pid:
                desired.add((parent.node_id, process.node_id))

        for key in list(self._edges):
            if key in desired or key[0] in self._ghosts or key[1] in self._ghosts:
                continue
            self._remove_edge(key)
        for key in desired:
            if key not in self._edges:
                edge = ProcessEdge(self._nodes[key[0]], self._nodes[key[1]])
                self.graph_scene.addItem(edge)
                self._edges[key] = edge

    def _remove_edge(self, key: tuple[str, str]) -> None:
        edge = self._edges.pop(key, None)
        if edge is None:
            return
        for end in (edge.source, edge.target):
            if edge in end.edges:
                end.edges.remove(edge)
        self.graph_scene.removeItem(edge)

    def _drop_ghost(self, node_id: str) -> None:
        node = self._ghosts.pop(node_id, None)
        if node is None:
            return
        for key in [k for k in self._edges if node_id in k]:
            self._remove_edge(key)
        self.graph_scene.removeItem(node)

    def _relayout(self, first: bool = False, reheat: float = 0.6) -> None:
        processes = list(self._processes.values())
        if not processes:
            self._targets = {}
            return
        self._ring_base = self._compute_ring_base(processes)
        radial = radial_layout(processes)

        if self._mode == "force":
            if len(self._nodes) > ForceLayout.MAX_NODES:
                self._mode = "radial"
                self.layout_mode_changed.emit("radial")
            else:
                if first:
                    for node_id, pos in radial.items():
                        node = self._nodes.get(node_id)
                        if node is not None:
                            node.setPos(*pos)
                initial = {nid: (n.x(), n.y()) for nid, n in self._nodes.items()}
                self._force.set_graph(list(self._nodes), list(self._edges), initial)
                self._force.reheat(1.0 if first else reheat)
                self._targets = {}
                return

        self._targets = radial
        if first:
            for node_id, pos in radial.items():
                node = self._nodes.get(node_id)
                if node is not None:
                    node.setPos(*pos)

    @staticmethod
    def _compute_ring_base(processes: list[ProcessSnapshot]) -> float:
        pids = {p.pid for p in processes}
        roots = sum(1 for p in processes if p.ppid not in pids or p.ppid == p.pid)
        return 0.0 if roots == 1 else 170.0

    # ------------------------------------------------------------------ #
    # Filtering / highlighting
    # ------------------------------------------------------------------ #
    def _apply_filter(self) -> None:
        text = self._filter
        for node in self._nodes.values():
            dim = not matches(text, node.process)
            if dim != node.dimmed:
                node.dimmed = dim
                node.restyle()
        for edge in self._edges.values():
            edge.refresh_dim()

    def _selection_changed(self) -> None:
        selected = [i for i in self.graph_scene.selectedItems() if isinstance(i, ProcessNode)]
        if selected:
            node = selected[0]
            self._selected_id = node.process.node_id
            self._update_highlight(self._selected_id)
            self.process_selected.emit(node.process)
        else:
            self._selected_id = None
            self._update_highlight(None)
            self.selection_cleared.emit()

    def _update_highlight(self, node_id: str | None) -> None:
        pairs: set[tuple[str, str]] = set()
        if node_id is not None:
            chain = ancestry_chain(node_id, self._processes)
            pairs = {(chain[i + 1], chain[i]) for i in range(len(chain) - 1)}
        for key, edge in self._edges.items():
            edge.set_highlight(key in pairs)

    # ------------------------------------------------------------------ #
    # Animation
    # ------------------------------------------------------------------ #
    def _ensure_anim(self) -> None:
        if not self._anim.isActive():
            self._anim.start()

    def _tick(self) -> None:
        active = False

        for node_id in list(self._ghosts):
            node = self._ghosts[node_id]
            node.ghost_ms -= ANIM_INTERVAL_MS
            if node.ghost_ms <= 0:
                self._drop_ghost(node_id)
            else:
                node.restyle()
                active = True

        for node in self._nodes.values():
            if node.flash > 0.0:
                node.flash = max(0.0, node.flash - FLASH_DECAY)
                node.restyle()
                active = True

        if self._mode == "force":
            active = self._tick_force() or active
        else:
            active = self._tick_radial() or active

        if not active and self._drag_node is None:
            self._anim.stop()

    def _tick_radial(self) -> bool:
        moving = False
        for node_id, node in self._nodes.items():
            if node.dragging or node.manual:
                continue
            target = self._targets.get(node_id)
            if target is None:
                continue
            dx = target[0] - node.x()
            dy = target[1] - node.y()
            if abs(dx) < 0.4 and abs(dy) < 0.4:
                if dx or dy:
                    node.setPos(*target)
                continue
            node.setPos(node.x() + dx * 0.22, node.y() + dy * 0.22)
            moving = True
        return moving

    def _tick_force(self) -> bool:
        for node_id, node in self._nodes.items():
            if node.dragging:
                self._force.pin(node_id, node.x(), node.y())
        if self._force.asleep:
            return False
        awake = self._force.step(1)
        positions = self._force.positions()
        for node_id, node in self._nodes.items():
            if node.dragging:
                continue
            pos = positions.get(node_id)
            if pos is not None:
                node.setPos(*pos)
        return awake

    # ------------------------------------------------------------------ #
    # Qt events
    # ------------------------------------------------------------------ #
    def _node_at(self, pos) -> ProcessNode | None:
        item = self.itemAt(pos)
        while item is not None and not isinstance(item, ProcessNode):
            item = item.parentItem()
        return item

    def mousePressEvent(self, event) -> None:
        super().mousePressEvent(event)
        if event.button() == Qt.MouseButton.LeftButton:
            node = self._node_at(event.position().toPoint())
            if node is not None and not node.ghost:
                node.dragging = True
                self._drag_node = node
                self._ensure_anim()

    def mouseReleaseEvent(self, event) -> None:
        node, self._drag_node = self._drag_node, None
        super().mouseReleaseEvent(event)
        if node is not None:
            node.dragging = False
            if self._mode == "force":
                self._force.unpin(node.process.node_id)
            else:
                node.manual = True
            self._ensure_anim()

    def wheelEvent(self, event) -> None:
        delta = event.angleDelta().y()
        if delta == 0:
            return
        factor = 1.18 ** (delta / 120.0)
        current = self.transform().m11()
        target = max(MIN_ZOOM, min(MAX_ZOOM, current * factor))
        factor = target / current if current else 1.0
        self.scale(factor, factor)

    def keyPressEvent(self, event) -> None:
        key = event.key()
        if key == Qt.Key.Key_F:
            self.fit_graph()
        elif key == Qt.Key.Key_R:
            self.relayout()
        elif key == Qt.Key.Key_L:
            self.toggle_layout()
        else:
            super().keyPressEvent(event)

    def drawBackground(self, painter, rect) -> None:
        painter.fillRect(rect, BACKGROUND)
        if self._mode != "radial" or not self._nodes:
            return
        pen = QPen(RING_COLOR, 1.0)
        pen.setCosmetic(True)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        reach = max((math.hypot(n.x(), n.y()) for n in self._nodes.values()), default=0.0)
        radius = self._ring_base if self._ring_base > 0 else 175.0
        step = 175.0
        origin = QPointF(0.0, 0.0)
        for _ in range(14):
            if radius > reach + step:
                break
            painter.drawEllipse(origin, radius, radius)
            radius += step
