"""Runs the engine on its own thread so the UI never blocks on /proc or SQLite."""

from __future__ import annotations

from PySide6.QtCore import QObject, QTimer, Signal, Slot

from ghostcore.core.engine import Engine


class EngineWorker(QObject):
    polled = Signal(object)      # PollResult
    failed = Signal(str)

    def __init__(self, engine: Engine, interval_ms: int) -> None:
        super().__init__()
        self._engine = engine
        self._interval_ms = interval_ms
        self._timer: QTimer | None = None
        self._paused = False

    @Slot()
    def start(self) -> None:
        # Created here so the timer lives in (and fires on) the worker thread.
        self._timer = QTimer(self)
        self._timer.setInterval(self._interval_ms)
        self._timer.timeout.connect(self.tick)
        try:
            self._engine.start()
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")
        self.tick()
        self._timer.start()

    @Slot()
    def tick(self) -> None:
        if self._paused:
            return
        try:
            result = self._engine.tick()
        except Exception as exc:  # keep the timer alive; report and retry
            self.failed.emit(f"{type(exc).__name__}: {exc}")
            return
        self.polled.emit(result)

    @Slot(bool)
    def set_paused(self, paused: bool) -> None:
        self._paused = bool(paused)

    @Slot()
    def refresh_now(self) -> None:
        was_paused, self._paused = self._paused, False
        self.tick()
        self._paused = was_paused

    @Slot()
    def shutdown(self) -> None:
        if self._timer is not None:
            self._timer.stop()
        self._engine.close()
