"""Main GHOSTCORE desktop window."""

from __future__ import annotations

import pwd

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from ghostcore.collectors.procfs import ProcessSnapshot, process_age_seconds
from ghostcore.core.config import AppConfig
from ghostcore.core.engine import Engine
from ghostcore.core.graph_model import (
    format_bytes,
    format_duration,
    state_color,
    state_name,
    top_by_cpu,
)
from ghostcore.core.monitor import PollResult
from ghostcore.core.series import SeriesStore
from ghostcore.ui.graph_view import ProcessGraphView
from ghostcore.ui.widgets import Sparkline
from ghostcore.ui.worker import EngineWorker

TOP_COUNT = 8

STYLE = """
    QMainWindow, QWidget {
        background: #0B0F19;
        color: #E2E8F0;
        font-family: "DejaVu Sans";
        font-size: 12px;
    }
    QLabel#brand {
        color: #C4B5FD; font-size: 24px; font-weight: 800; letter-spacing: 3px;
    }
    QLabel#muted { color: #7C89A5; font-size: 10px; }
    QLabel#live { color: #6EE7B7; font-weight: bold; }
    QLabel#system { color: #93A4C3; font-size: 11px; }
    QFrame#panel {
        background: #111827; border: 1px solid #273249; border-radius: 10px;
    }
    QLabel#section { color: #8B5CF6; font-weight: bold; letter-spacing: 1px; }
    QLabel#process_name { color: #67E8F9; font-size: 17px; font-weight: bold; }
    QLabel#cmdline { color: #7C89A5; font-size: 10px; }
    QSplitter::handle { background: #273249; width: 4px; }
    QLineEdit {
        background: #111827; border: 1px solid #273249; border-radius: 6px;
        padding: 5px 8px; selection-background-color: #8B5CF6;
    }
    QLineEdit:focus { border: 1px solid #8B5CF6; }
    QPushButton {
        background: #1B2438; border: 1px solid #273249; border-radius: 6px;
        padding: 5px 12px;
    }
    QPushButton:hover { border: 1px solid #8B5CF6; }
    QPushButton:checked { background: #3B2A6B; border: 1px solid #8B5CF6; }
    QListWidget {
        background: #0E1626; border: 1px solid #273249; border-radius: 6px;
        outline: none;
    }
    QListWidget::item { padding: 3px 6px; }
    QListWidget::item:hover { background: #1B2438; }
    QListWidget::item:selected { background: #3B2A6B; color: #E2E8F0; }
    QMenuBar { background: #0B0F19; }
    QMenuBar::item:selected { background: #1B2438; }
    QMenu { background: #111827; border: 1px solid #273249; }
    QMenu::item:selected { background: #3B2A6B; }
"""

_user_cache: dict[int, str] = {}


def user_name(uid: int) -> str:
    if uid < 0:
        return "—"
    if uid not in _user_cache:
        try:
            _user_cache[uid] = pwd.getpwuid(uid).pw_name
        except KeyError:
            _user_cache[uid] = str(uid)
    return _user_cache[uid]


class MainWindow(QMainWindow):
    request_shutdown = Signal()
    request_pause = Signal(bool)
    request_refresh = Signal()

    def __init__(
        self, engine: Engine, config: AppConfig, warnings: list[str] | None = None
    ) -> None:
        super().__init__()
        self.engine = engine
        self.config = config
        self.series = SeriesStore()
        self.latest: PollResult | None = None
        self._by_id: dict[str, ProcessSnapshot] = {}
        self.selected_id: str | None = None
        self._cmdline_cache: tuple[str, str] | None = None
        self._warnings = list(warnings or [])

        self.setWindowTitle("GHOSTCORE // Live Process Graph")
        self.resize(1720, 1080)
        self.setMinimumSize(1100, 720)
        self._build_ui()
        self._build_menu()
        self.setStyleSheet(STYLE)
        self._start_worker()

    # ------------------------------------------------------------------ #
    # UI construction
    # ------------------------------------------------------------------ #
    def _build_ui(self) -> None:
        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(18, 16, 18, 12)
        root_layout.setSpacing(12)

        header = QHBoxLayout()
        brand = QLabel("GHOSTCORE")
        brand.setObjectName("brand")
        subtitle = QLabel("PROCESS UNIVERSE // GCP v1")
        subtitle.setObjectName("muted")
        header.addWidget(brand)
        header.addSpacing(18)
        header.addWidget(subtitle)
        header.addStretch()
        self.system_label = QLabel("")
        self.system_label.setObjectName("system")
        header.addWidget(self.system_label)
        header.addSpacing(18)
        self.live_label = QLabel("● INITIALIZING")
        self.live_label.setObjectName("live")
        header.addWidget(self.live_label)
        root_layout.addLayout(header)

        controls = QHBoxLayout()
        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Filter: name, pid, or state:Z   (Ctrl+F)")
        self.filter_edit.setClearButtonEnabled(True)
        self.pause_button = QPushButton("Pause")
        self.pause_button.setCheckable(True)
        self.layout_button = QPushButton("Layout: radial")
        self.fit_button = QPushButton("Fit")
        controls.addWidget(self.filter_edit, 1)
        controls.addWidget(self.pause_button)
        controls.addWidget(self.layout_button)
        controls.addWidget(self.fit_button)
        root_layout.addLayout(controls)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.graph = ProcessGraphView()
        splitter.addWidget(self.graph)
        splitter.addWidget(self._build_side_panel())
        splitter.setSizes([1250, 340])
        root_layout.addWidget(splitter, 1)

        self.status_label = QLabel("Waiting for first snapshot...")
        self.status_label.setObjectName("muted")
        root_layout.addWidget(self.status_label)
        self.setCentralWidget(root)

        self.graph.process_selected.connect(self.show_process)
        self.graph.selection_cleared.connect(self.clear_selection)
        self.graph.layout_mode_changed.connect(self._layout_mode_changed)
        self.filter_edit.textChanged.connect(self.graph.set_filter)
        self.pause_button.toggled.connect(self._pause_toggled)
        self.layout_button.clicked.connect(self.graph.toggle_layout)
        self.fit_button.clicked.connect(self.graph.fit_graph)

    def _build_side_panel(self) -> QWidget:
        side = QFrame()
        side.setObjectName("panel")
        side.setMinimumWidth(270)
        side.setMaximumWidth(380)
        layout = QVBoxLayout(side)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(8)

        title = QLabel("PROCESS INSPECTOR")
        title.setObjectName("section")
        self.name_label = QLabel("Select a node")
        self.name_label.setObjectName("process_name")
        self.name_label.setWordWrap(True)
        self.state_label = QLabel("")
        self.pid_label = QLabel("PID: —")
        self.ppid_label = QLabel("PPID: —")
        self.user_label = QLabel("User: —")
        self.threads_label = QLabel("Threads: —")
        self.age_label = QLabel("Running for: —")
        self.cpu_label = QLabel("CPU: —")
        self.memory_label = QLabel("Memory: —")
        self.cmdline_label = QLabel("")
        self.cmdline_label.setObjectName("cmdline")
        self.cmdline_label.setWordWrap(True)
        self.cmdline_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.identity_label = QLabel("")
        self.identity_label.setObjectName("muted")

        for widget in (
            title, self.name_label, self.state_label, self.pid_label, self.ppid_label,
            self.user_label, self.threads_label, self.age_label,
        ):
            layout.addWidget(widget)

        layout.addWidget(self.cpu_label)
        self.cpu_spark = Sparkline("#22D3EE")
        layout.addWidget(self.cpu_spark)
        layout.addWidget(self.memory_label)
        self.mem_spark = Sparkline("#8B5CF6")
        layout.addWidget(self.mem_spark)
        layout.addWidget(self.cmdline_label)
        layout.addWidget(self.identity_label)

        layout.addSpacing(6)
        top_title = QLabel("TOP CPU")
        top_title.setObjectName("section")
        layout.addWidget(top_title)
        self.top_list = QListWidget()
        self.top_list.setFixedHeight(TOP_COUNT * 26 + 8)
        self.top_list.itemClicked.connect(self._top_clicked)
        layout.addWidget(self.top_list)

        layout.addStretch()
        hint = QLabel(
            "SCROLL  // ZOOM\nDRAG    // PAN / MOVE NODE\nHOVER   // LABEL\n"
            "CLICK   // INSPECT + TRACE ANCESTRY\nF  FIT   R  RELAYOUT   L  LAYOUT"
        )
        hint.setObjectName("muted")
        layout.addWidget(hint)
        return side

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("&File")
        export = QAction("Export snapshot (GCP JSONL)…", self)
        export.setShortcut(QKeySequence("Ctrl+E"))
        export.triggered.connect(self.export_snapshot)
        quit_action = QAction("&Quit", self)
        quit_action.setShortcut(QKeySequence("Ctrl+Q"))
        quit_action.triggered.connect(self.close)
        file_menu.addAction(export)
        file_menu.addSeparator()
        file_menu.addAction(quit_action)

        view_menu = self.menuBar().addMenu("&View")
        for text, shortcut, slot in (
            ("Focus filter", "Ctrl+F", self.filter_edit.setFocus),
            ("Pause / resume", "Ctrl+P", self.pause_button.toggle),
            ("Toggle layout", "Ctrl+L", self.graph.toggle_layout),
            ("Re-layout", "Ctrl+R", self.graph.relayout),
            ("Fit to view", "Ctrl+0", self.graph.fit_graph),
        ):
            action = QAction(text, self)
            action.setShortcut(QKeySequence(shortcut))
            action.triggered.connect(slot)
            view_menu.addAction(action)

    # ------------------------------------------------------------------ #
    # Worker thread
    # ------------------------------------------------------------------ #
    def _start_worker(self) -> None:
        self._thread = QThread(self)
        self._worker = EngineWorker(self.engine, self.config.interval_ms)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.start)
        self._worker.polled.connect(self.on_polled)
        self._worker.failed.connect(self.on_failed)
        self.request_shutdown.connect(self._worker.shutdown)
        self.request_pause.connect(self._worker.set_paused)
        self.request_refresh.connect(self._worker.refresh_now)
        self._thread.start()

    def closeEvent(self, event) -> None:  # noqa: N802 (Qt API)
        self.request_shutdown.emit()    # queued: runs on the worker thread first
        self._thread.quit()
        self._thread.wait(5000)
        self.engine.close()             # idempotent safety net
        super().closeEvent(event)

    # ------------------------------------------------------------------ #
    # Live updates
    # ------------------------------------------------------------------ #
    def on_polled(self, result: PollResult) -> None:
        self.latest = result
        self._by_id = {s.node_id: s for s in result.snapshots}
        self.series.record(result)
        self.graph.update_processes(result.snapshots, result.cpu_percent)
        self._update_header(result)
        self._update_top_list(result)
        self._refresh_inspector()

        paused = self.pause_button.isChecked()
        self.live_label.setText("● PAUSED" if paused else "● LIVE")
        parts = [
            "GCP v1",
            f"{len(result.snapshots)} processes",
            f"interval: {self.config.interval_ms} ms",
            "source: /proc",
        ]
        if self.config.db_path and self.engine.store is not None:
            parts.append("recording → SQLite")
        if self.engine.server is not None:
            parts.append(f"stream: {self.config.socket_path} ({self.engine.server.client_count} clients)")
        parts.extend(self._warnings)
        self.status_label.setText("  |  ".join(parts))

    def on_failed(self, message: str) -> None:
        self.live_label.setText("● ERROR")
        self.status_label.setText(f"Collector error: {message}")

    def _update_header(self, result: PollResult) -> None:
        system = result.system
        if system is None:
            self.system_label.setText("")
            return
        self.system_label.setText(
            f"LOAD {system.load1:.2f}   MEM {system.mem_used_ratio * 100:.0f}%   "
            f"UP {format_duration(system.uptime_s)}"
        )

    def _update_top_list(self, result: PollResult) -> None:
        self.top_list.blockSignals(True)
        self.top_list.clear()
        for snap, cpu in top_by_cpu(result.snapshots, result.cpu_percent, TOP_COUNT):
            item = QListWidgetItem(f"{cpu:5.1f}%   {snap.name} [{snap.pid}]")
            item.setData(Qt.ItemDataRole.UserRole, snap.node_id)
            self.top_list.addItem(item)
            if snap.node_id == self.selected_id:
                item.setSelected(True)
        self.top_list.blockSignals(False)

    def _top_clicked(self, item: QListWidgetItem) -> None:
        node_id = item.data(Qt.ItemDataRole.UserRole)
        if node_id:
            self.graph.select_node(node_id)

    # ------------------------------------------------------------------ #
    # Inspector
    # ------------------------------------------------------------------ #
    def show_process(self, process: ProcessSnapshot) -> None:
        self.selected_id = process.node_id
        # Command lines can contain secrets, so they are read on demand and
        # only displayed locally; they never enter events, the DB or the socket.
        self._cmdline_cache = (
            process.node_id,
            self.engine.collector.read_cmdline(process.pid),
        )
        self._refresh_inspector()

    def clear_selection(self) -> None:
        self.selected_id = None
        self._cmdline_cache = None
        self.name_label.setText("Select a node")
        self.state_label.setText("")
        for label, text in (
            (self.pid_label, "PID: —"), (self.ppid_label, "PPID: —"),
            (self.user_label, "User: —"), (self.threads_label, "Threads: —"),
            (self.age_label, "Running for: —"), (self.cpu_label, "CPU: —"),
            (self.memory_label, "Memory: —"), (self.cmdline_label, ""),
            (self.identity_label, ""),
        ):
            label.setText(text)
        self.cpu_spark.set_values([])
        self.mem_spark.set_values([])

    def _refresh_inspector(self) -> None:
        node_id = self.selected_id
        if node_id is None or self.latest is None:
            return
        snap = self._by_id.get(node_id)
        if snap is None:
            self.name_label.setText("(process exited)")
            self.state_label.setText("")
            return

        self.name_label.setText(snap.name)
        color = state_color(snap.state)
        self.state_label.setText(
            f'<span style="color:{color}; font-weight:bold;">● {snap.state}</span>'
            f"  {state_name(snap.state)}"
        )
        cpu = self.latest.cpu_of(node_id)
        self.pid_label.setText(f"PID: {snap.pid}")
        self.ppid_label.setText(f"PPID: {snap.ppid}")
        self.user_label.setText(f"User: {user_name(snap.uid)}")
        self.threads_label.setText(f"Threads: {snap.num_threads}")
        if self.latest.system is not None:
            age = process_age_seconds(
                snap, self.latest.system.uptime_s, self.engine.collector.clock_ticks
            )
            self.age_label.setText(f"Running for: {format_duration(age)}")
        self.cpu_label.setText(f"CPU: {cpu:.1f}%")
        self.memory_label.setText(f"RSS memory: {format_bytes(snap.memory_bytes)}")
        self.identity_label.setText(f"Node ID: {snap.node_id}")
        if self._cmdline_cache and self._cmdline_cache[0] == node_id:
            self.cmdline_label.setText(self._cmdline_cache[1])
        self.cpu_spark.set_values(self.series.cpu(node_id))
        self.mem_spark.set_values(self.series.memory(node_id))

    # ------------------------------------------------------------------ #
    # Actions
    # ------------------------------------------------------------------ #
    def _pause_toggled(self, paused: bool) -> None:
        self.pause_button.setText("Resume" if paused else "Pause")
        self.live_label.setText("● PAUSED" if paused else "● LIVE")
        self.request_pause.emit(paused)

    def _layout_mode_changed(self, mode: str) -> None:
        self.layout_button.setText(f"Layout: {mode}")

    def export_snapshot(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Export snapshot", "ghostcore-snapshot.jsonl",
            "GCP JSON Lines (*.jsonl);;All files (*)",
        )
        if not path:
            return
        events = self.engine.monitor.snapshot_events()
        try:
            with open(path, "wb") as handle:
                for event in events:
                    handle.write(event.encode())
        except OSError as exc:
            QMessageBox.warning(self, "Export failed", str(exc))
            return
        self.status_label.setText(f"Exported {len(events)} processes to {path}")
