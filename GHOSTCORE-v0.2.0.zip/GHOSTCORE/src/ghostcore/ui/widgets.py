"""Small reusable Qt widgets."""

from __future__ import annotations

from typing import Sequence

from PySide6.QtCore import QPointF
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget


class Sparkline(QWidget):
    """Tiny filled line chart for a rolling series."""

    def __init__(self, color: str = "#22D3EE", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._color = QColor(color)
        self._values: list[float] = []
        self._ceiling: float | None = None
        self.setFixedHeight(46)
        self.setMinimumWidth(120)

    def set_values(self, values: Sequence[float], ceiling: float | None = None) -> None:
        self._values = [float(v) for v in values]
        self._ceiling = ceiling
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 (Qt API)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)
        painter.fillRect(rect, QColor("#0E1626"))
        painter.setPen(QPen(QColor("#273249"), 1))
        painter.drawRect(rect)

        values = self._values
        if len(values) < 2 or rect.width() <= 2 or rect.height() <= 2:
            return

        top = self._ceiling if self._ceiling else max(max(values), 1e-9) * 1.15
        top = max(top, 1e-9)
        step = rect.width() / (len(values) - 1)
        base_y = float(rect.bottom())

        def point(i: int, v: float) -> QPointF:
            ratio = max(0.0, min(1.0, v / top))
            return QPointF(rect.left() + i * step, base_y - ratio * (rect.height() - 2))

        line = QPainterPath()
        line.moveTo(point(0, values[0]))
        for i in range(1, len(values)):
            line.lineTo(point(i, values[i]))

        area = QPainterPath(line)
        area.lineTo(QPointF(rect.left() + (len(values) - 1) * step, base_y))
        area.lineTo(QPointF(float(rect.left()), base_y))
        area.closeSubpath()

        fill = QColor(self._color)
        fill.setAlpha(55)
        painter.fillPath(area, fill)
        painter.setPen(QPen(self._color, 1.6))
        painter.drawPath(line)
