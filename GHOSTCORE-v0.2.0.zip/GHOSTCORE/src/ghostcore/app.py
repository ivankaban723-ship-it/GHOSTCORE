"""GHOSTCORE application entry point."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from ghostcore.core.config import AppConfig
from ghostcore.core.engine import build_engine


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ghostcore", description="GHOSTCORE process universe")
    parser.add_argument("--interval-ms", type=int, default=1500, help="refresh interval (min 200)")
    parser.add_argument("--db", help="record events into this SQLite file")
    parser.add_argument("--socket", help="serve the GCP stream on this Unix socket (mode 0600)")
    parser.add_argument("--plugins-dir", help="load *.py plugins from a TRUSTED directory")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args, qt_args = build_parser().parse_known_args(
        list(argv) if argv is not None else sys.argv[1:]
    )
    config = AppConfig(
        interval_ms=args.interval_ms,
        db_path=args.db,
        socket_path=args.socket,
        plugins_dir=args.plugins_dir,
    )

    # Imported lazily so `ghostcore --help` and headless tooling work without Qt.
    from PySide6.QtWidgets import QApplication

    from ghostcore.ui.main_window import MainWindow

    app = QApplication([sys.argv[0], *qt_args])
    app.setApplicationName("GHOSTCORE")
    app.setOrganizationName("GHOSTCORE")
    engine, warnings = build_engine(config)
    window = MainWindow(engine, config, warnings)
    window.show()
    code = app.exec()
    engine.close()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
