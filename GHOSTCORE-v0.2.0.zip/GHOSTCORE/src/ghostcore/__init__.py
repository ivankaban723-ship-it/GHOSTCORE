"""GHOSTCORE: Linux process observability toolkit."""

__version__ = "0.2.0"
