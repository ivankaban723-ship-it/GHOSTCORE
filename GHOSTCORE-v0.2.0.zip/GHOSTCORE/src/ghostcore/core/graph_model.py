"""Pure (Qt-free) helpers behind the graph view, so they can be unit-tested."""

from __future__ import annotations

import math
from typing import Iterable, Mapping, Sequence

from ghostcore.collectors.procfs import ProcessSnapshot

STATE_COLORS: dict[str, str] = {
    "R": "#34D399",   # running
    "S": "#8B5CF6",   # sleeping
    "D": "#F59E0B",   # uninterruptible disk wait
    "Z": "#F43F5E",   # zombie
    "T": "#60A5FA",   # stopped
    "t": "#60A5FA",   # tracing stop
    "I": "#64748B",   # idle kernel thread
}
DEFAULT_STATE_COLOR = "#94A3B8"

STATE_NAMES: dict[str, str] = {
    "R": "running",
    "S": "sleeping",
    "D": "disk wait",
    "Z": "zombie",
    "T": "stopped",
    "t": "tracing stop",
    "I": "idle",
    "X": "dead",
}


def state_color(state: str) -> str:
    return STATE_COLORS.get(state, DEFAULT_STATE_COLOR)


def state_name(state: str) -> str:
    return STATE_NAMES.get(state, "unknown")


def node_radius(
    memory_bytes: int, min_radius: float = 6.0, max_radius: float = 18.0
) -> float:
    """Log-scaled node size: 0 MiB -> min, 4 GiB and above -> max."""
    mib = max(0.0, memory_bytes) / (1024 * 1024)
    t = math.log10(1.0 + mib) / math.log10(1.0 + 4096.0)
    t = max(0.0, min(1.0, t))
    return min_radius + (max_radius - min_radius) * t


def matches(query: str, snap: ProcessSnapshot) -> bool:
    """Filter syntax: ``text`` (name or pid substring) or ``state:Z``."""
    q = query.strip()
    if not q:
        return True
    lowered = q.lower()
    if lowered.startswith("state:"):
        wanted = q[6:].strip()
        return bool(wanted) and snap.state.lower() == wanted.lower()
    return lowered in snap.name.lower() or lowered in str(snap.pid)


def ancestry_chain(
    node_id: str, processes: Mapping[str, ProcessSnapshot]
) -> list[str]:
    """node_id, its parent, grandparent... up to the root (cycle-safe)."""
    by_pid = {p.pid: p for p in processes.values()}
    chain: list[str] = []
    seen: set[str] = set()
    current = processes.get(node_id)
    while current is not None and current.node_id not in seen:
        seen.add(current.node_id)
        chain.append(current.node_id)
        if current.ppid == current.pid:
            break
        current = by_pid.get(current.ppid)
    return chain


def top_by_cpu(
    snapshots: Iterable[ProcessSnapshot],
    cpu_percent: Mapping[str, float],
    count: int = 8,
) -> list[tuple[ProcessSnapshot, float]]:
    ranked = sorted(
        ((s, cpu_percent.get(s.node_id, 0.0)) for s in snapshots),
        key=lambda item: (-item[1], -item[0].memory_bytes, item[0].pid),
    )
    return ranked[:count]


def topology_signature(snapshots: Sequence[ProcessSnapshot]) -> frozenset:
    return frozenset((s.node_id, s.ppid) for s in snapshots)


def format_bytes(value: float) -> str:
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if abs(size) < 1024.0 or unit == "TiB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024.0
    return f"{size:.1f} TiB"  # pragma: no cover


def format_duration(seconds: float) -> str:
    total = int(max(0, seconds))
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    if days:
        return f"{days}d {hours}h"
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {secs}s"
    return f"{secs}s"
