"""Headless engine: monitor + plugins + bus (+ optional store and socket)."""

from __future__ import annotations

import logging
import threading
import time

from ghostcore.collectors.procfs import ProcfsCollector
from ghostcore.core.bus import EventBus
from ghostcore.core.config import AppConfig
from ghostcore.core.monitor import PollResult, ProcessMonitor
from ghostcore.core.store import EventStore
from ghostcore.core.transport import GCPServer
from ghostcore.plugins.manager import PluginManager

log = logging.getLogger(__name__)

PRUNE_EVERY_TICKS = 400


class Engine:
    def __init__(
        self,
        collector: ProcfsCollector | None = None,
        bus: EventBus | None = None,
        plugins: PluginManager | None = None,
        store: EventStore | None = None,
        server: GCPServer | None = None,
        retention_hours: float = 24.0,
        max_rows: int = 2_000_000,
    ) -> None:
        self.collector = collector or ProcfsCollector()
        self.monitor = ProcessMonitor(self.collector)
        self.bus = bus or EventBus()
        self.plugins = plugins or PluginManager()
        self.store = store
        self.server = server
        self.retention_hours = retention_hours
        self.max_rows = max_rows
        self._ticks = 0
        self._closed = False
        self._started = False

        if self.store is not None:
            self.bus.subscribe_batch(self.store.append_many)
        if self.server is not None:
            self.bus.subscribe_batch(self.server.broadcast)

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        self.plugins.start_all()

    def tick(self) -> PollResult:
        """One full cycle: poll /proc, publish events, run plugins."""
        result = self.monitor.poll()
        events = self.monitor.to_events(result)
        events += self.plugins.dispatch_poll(result)
        events += self.plugins.collect_all()
        self.bus.publish_many(events)

        self._ticks += 1
        if self.store is not None and self._ticks % PRUNE_EVERY_TICKS == 0:
            self.store.prune(
                max_age_s=self.retention_hours * 3600, max_rows=self.max_rows
            )
        return result

    def run_forever(self, interval_s: float, stop: threading.Event | None = None) -> None:
        stop = stop or threading.Event()
        self.start()
        while not stop.is_set():
            started = time.monotonic()
            self.tick()
            stop.wait(max(0.0, interval_s - (time.monotonic() - started)))

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self.plugins.stop_all()
        if self.server is not None:
            self.server.close()
        if self.store is not None:
            self.store.close()


def build_engine(config: AppConfig) -> tuple[Engine, list[str]]:
    """Create an engine from a config. Non-fatal problems become warnings."""
    warnings: list[str] = []
    plugins = PluginManager()
    if config.plugins_dir:
        plugins.discover(config.plugins_dir)
        warnings.extend(f"plugin: {reason}" for reason in plugins.rejected)

    store = None
    if config.db_path:
        try:
            store = EventStore(config.db_path)
        except Exception as exc:
            warnings.append(f"history disabled: {exc}")

    engine = Engine(
        plugins=plugins,
        store=store,
        retention_hours=config.retention_hours,
        max_rows=config.max_rows,
    )

    if config.socket_path:
        server = GCPServer(config.socket_path, snapshot_provider=engine.monitor.snapshot_events)
        try:
            server.start()
        except Exception as exc:
            warnings.append(f"socket disabled: {exc}")
        else:
            engine.server = server
            engine.bus.subscribe_batch(server.broadcast)
    return engine, warnings
