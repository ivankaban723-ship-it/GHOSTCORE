"""In-memory time series for the live UI (sparklines)."""

from __future__ import annotations

from collections import deque

from ghostcore.core.monitor import PollResult


class SeriesStore:
    def __init__(self, maxlen: int = 120) -> None:
        self.maxlen = maxlen
        self._cpu: dict[str, deque[float]] = {}
        self._mem: dict[str, deque[float]] = {}
        self.total_cpu: deque[float] = deque(maxlen=maxlen)
        self.mem_used: deque[float] = deque(maxlen=maxlen)

    def record(self, result: PollResult) -> None:
        live: set[str] = set()
        total = 0.0
        for snap in result.snapshots:
            node_id = snap.node_id
            live.add(node_id)
            cpu = result.cpu_of(node_id)
            total += cpu
            self._cpu.setdefault(node_id, deque(maxlen=self.maxlen)).append(cpu)
            self._mem.setdefault(node_id, deque(maxlen=self.maxlen)).append(
                float(snap.memory_bytes)
            )
        for node_id in [n for n in self._cpu if n not in live]:
            del self._cpu[node_id]
            self._mem.pop(node_id, None)
        self.total_cpu.append(total)
        if result.system is not None:
            self.mem_used.append(result.system.mem_used_ratio)

    def cpu(self, node_id: str) -> list[float]:
        return list(self._cpu.get(node_id, ()))

    def memory(self, node_id: str) -> list[float]:
        return list(self._mem.get(node_id, ()))

    def tracked(self) -> int:
        return len(self._cpu)
