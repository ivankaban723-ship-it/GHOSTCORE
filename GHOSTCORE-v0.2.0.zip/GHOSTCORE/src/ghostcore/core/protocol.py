"""GCP v1 — GhostCore Protocol.

Wire format: UTF-8 JSON Lines, one event per line.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Mapping

PROTOCOL_NAME = "GCP"
PROTOCOL_VERSION = 1

# Hard limit for one encoded event (including the trailing newline). Decoders
# reject anything larger so a misbehaving peer cannot exhaust memory.
MAX_EVENT_BYTES = 1024 * 1024


class EventType:
    """Event types emitted by the GHOSTCORE core.

    The ``process.`` and ``system.`` namespaces are reserved for the core;
    plugins must use their own namespace (for example ``alert.zombie``).
    """

    PROCESS_SNAPSHOT = "process.snapshot"
    PROCESS_SPAWNED = "process.spawned"
    PROCESS_EXITED = "process.exited"
    PROCESS_SAMPLE = "process.sample"
    SYSTEM_SAMPLE = "system.sample"

    RESERVED_PREFIXES = ("process.", "system.")


@dataclass(frozen=True, slots=True)
class GCPEvent:
    event_type: str
    payload: dict[str, Any] = field(default_factory=dict)
    timestamp_ns: int = field(default_factory=time.time_ns)
    version: int = PROTOCOL_VERSION

    @property
    def node_id(self) -> str | None:
        """Process identity (``pid:start_ticks``) if the payload carries one."""
        value = self.payload.get("node_id")
        return value if isinstance(value, str) else None

    def to_dict(self) -> dict[str, Any]:
        return {
            "protocol": PROTOCOL_NAME,
            "version": self.version,
            "type": self.event_type,
            "timestamp_ns": self.timestamp_ns,
            "payload": self.payload,
        }

    def encode(self) -> bytes:
        """Encode one event as a UTF-8 JSON Lines record."""
        raw = (
            json.dumps(
                self.to_dict(),
                separators=(",", ":"),
                ensure_ascii=False,
            )
            + "\n"
        ).encode("utf-8")
        if len(raw) > MAX_EVENT_BYTES:
            raise ValueError("GCP event exceeds MAX_EVENT_BYTES")
        return raw

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "GCPEvent":
        if not isinstance(data, Mapping):
            raise ValueError("GCP event must be a JSON object")
        if data.get("protocol") != PROTOCOL_NAME:
            raise ValueError("Unknown protocol")
        if data.get("version") != PROTOCOL_VERSION:
            raise ValueError("Unsupported GCP version")

        event_type = data.get("type")
        payload = data.get("payload")
        timestamp_ns = data.get("timestamp_ns")

        if not isinstance(event_type, str) or not event_type:
            raise ValueError("Invalid event type")
        if not isinstance(payload, dict):
            raise ValueError("Event payload must be an object")
        if type(timestamp_ns) is not int or timestamp_ns < 0:
            raise ValueError("Invalid timestamp")

        return cls(
            event_type=event_type,
            payload=payload,
            timestamp_ns=timestamp_ns,
            version=PROTOCOL_VERSION,
        )

    @classmethod
    def decode(cls, raw: bytes | str) -> "GCPEvent":
        if len(raw) > MAX_EVENT_BYTES:
            raise ValueError("GCP event exceeds MAX_EVENT_BYTES")
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        return cls.from_dict(json.loads(raw))
