"""SQLite event history for GCP events."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Iterable, Sequence

from ghostcore.core.protocol import EventType, GCPEvent

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_ns   INTEGER NOT NULL,
    type    TEXT    NOT NULL,
    node_id TEXT,
    payload TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_ts      ON events (ts_ns);
CREATE INDEX IF NOT EXISTS idx_events_type_ts ON events (type, ts_ns);
CREATE INDEX IF NOT EXISTS idx_events_node_ts ON events (node_id, ts_ns);
"""


class EventStore:
    """Append-only history with simple retention. Thread-safe."""

    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).expanduser().parent.mkdir(parents=True, exist_ok=True)
            self.path = str(Path(self.path).expanduser())
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._closed = False
        with self._lock:
            if self.path != ":memory:":
                self._conn.execute("PRAGMA journal_mode=WAL")
                self._conn.execute("PRAGMA synchronous=NORMAL")
            version = self._conn.execute("PRAGMA user_version").fetchone()[0]
            if version > SCHEMA_VERSION:
                self._conn.close()
                raise RuntimeError(
                    f"Database schema {version} is newer than supported {SCHEMA_VERSION}"
                )
            self._conn.executescript(_SCHEMA)
            self._conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
            self._conn.commit()

    # ------------------------------------------------------------------ #
    def append(self, event: GCPEvent) -> None:
        self.append_many([event])

    def append_many(self, events: Sequence[GCPEvent]) -> None:
        if not events:
            return
        rows = [
            (
                e.timestamp_ns,
                e.event_type,
                e.node_id,
                json.dumps(e.payload, separators=(",", ":"), ensure_ascii=False),
            )
            for e in events
        ]
        with self._lock:
            if self._closed:
                return
            with self._conn:
                self._conn.executemany(
                    "INSERT INTO events (ts_ns, type, node_id, payload) VALUES (?,?,?,?)",
                    rows,
                )

    # ------------------------------------------------------------------ #
    def query(
        self,
        *,
        since_ns: int | None = None,
        until_ns: int | None = None,
        types: Iterable[str] | None = None,
        type_prefixes: Iterable[str] | None = None,
        node_id: str | None = None,
        limit: int = 1000,
        newest_first: bool = False,
    ) -> list[GCPEvent]:
        clauses: list[str] = []
        args: list[object] = []
        if since_ns is not None:
            clauses.append("ts_ns >= ?")
            args.append(since_ns)
        if until_ns is not None:
            clauses.append("ts_ns <= ?")
            args.append(until_ns)
        if node_id is not None:
            clauses.append("node_id = ?")
            args.append(node_id)
        if types is not None:
            type_list = list(types)
            if not type_list:
                return []
            clauses.append("type IN (%s)" % ",".join("?" * len(type_list)))
            args.extend(type_list)
        if type_prefixes is not None:
            prefix_list = list(type_prefixes)
            if not prefix_list:
                return []
            clauses.append(
                "(" + " OR ".join("type LIKE ? ESCAPE '\\'" for _ in prefix_list) + ")"
            )
            for prefix in prefix_list:
                escaped = (
                    prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                )
                args.append(escaped + "%")

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        order = "DESC" if newest_first else "ASC"
        sql = (
            "SELECT ts_ns, type, payload FROM events "
            f"{where} ORDER BY ts_ns {order}, id {order} LIMIT ?"
        )
        args.append(max(1, int(limit)))
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()
        return [
            GCPEvent(event_type=t, payload=json.loads(p), timestamp_ns=ts)
            for ts, t, p in rows
        ]

    def series(
        self, node_id: str, since_ns: int | None = None, limit: int = 5000
    ) -> list[tuple[int, float, int]]:
        """(timestamp_ns, cpu_percent, memory_bytes) samples of one process."""
        events = self.query(
            since_ns=since_ns,
            types=[EventType.PROCESS_SAMPLE],
            node_id=node_id,
            limit=limit,
        )
        return [
            (
                e.timestamp_ns,
                float(e.payload.get("cpu_percent", 0.0)),
                int(e.payload.get("memory_bytes", 0)),
            )
            for e in events
        ]

    def count(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM events").fetchone()[0])

    # ------------------------------------------------------------------ #
    def prune(
        self,
        *,
        max_age_s: float | None = None,
        max_rows: int | None = None,
        now_ns: int | None = None,
    ) -> int:
        """Delete old events. Returns the number of removed rows."""
        removed = 0
        with self._lock:
            if self._closed:
                return 0
            with self._conn:
                if max_age_s is not None:
                    cutoff = (now_ns if now_ns is not None else time.time_ns()) - int(
                        max_age_s * 1e9
                    )
                    removed += self._conn.execute(
                        "DELETE FROM events WHERE ts_ns < ?", (cutoff,)
                    ).rowcount
                if max_rows is not None and max_rows >= 0:
                    removed += self._conn.execute(
                        "DELETE FROM events WHERE id <= "
                        "(SELECT id FROM events ORDER BY id DESC LIMIT 1 OFFSET ?)",
                        (max_rows,),
                    ).rowcount
        return removed

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._closed = True
                self._conn.close()

    def __enter__(self) -> "EventStore":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
