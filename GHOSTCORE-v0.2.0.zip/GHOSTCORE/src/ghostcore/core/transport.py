"""Unix domain socket transport for GCP (server -> clients streaming).

Security model: the socket file is created with mode 0600, so only the owning
user can read the process stream. There is no further authentication.
"""

from __future__ import annotations

import contextlib
import logging
import os
import queue
import select
import socket
import stat
import threading
from pathlib import Path
from typing import Callable, Iterator, Sequence

from ghostcore.core.protocol import MAX_EVENT_BYTES, GCPEvent

log = logging.getLogger(__name__)

SnapshotProvider = Callable[[], Sequence[GCPEvent]]


def _peer_closed(sock: socket.socket) -> bool:
    """True if the peer has closed its end (clients never send data)."""
    try:
        readable, _, _ = select.select([sock], [], [], 0)
        if not readable:
            return False
        return sock.recv(1, socket.MSG_PEEK) == b""
    except (OSError, ValueError):
        return True


class _Client:
    def __init__(self, sock: socket.socket, queue_size: int) -> None:
        self.sock = sock
        self.queue: queue.Queue[bytes | None] = queue.Queue(maxsize=queue_size)
        self.alive = True
        self.thread: threading.Thread | None = None

    def shutdown(self) -> None:
        self.alive = False
        with contextlib.suppress(queue.Full):
            self.queue.put_nowait(None)
        with contextlib.suppress(OSError):
            self.sock.close()


class GCPServer:
    """Broadcasts GCP events to every connected client.

    New clients first receive the output of ``snapshot_provider`` (the current
    process list) so they never need history to know the present state. A
    client that cannot keep up (its queue overflows) is disconnected instead of
    slowing everyone else down.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        snapshot_provider: SnapshotProvider | None = None,
        max_clients: int = 16,
        queue_size: int = 256,
    ) -> None:
        self.path = Path(path)
        self._provider = snapshot_provider
        self._max_clients = max_clients
        self._queue_size = queue_size
        self._clients: list[_Client] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._listener: socket.socket | None = None
        self._thread: threading.Thread | None = None

    @property
    def client_count(self) -> int:
        with self._lock:
            return sum(1 for c in self._clients if c.alive)

    # ------------------------------------------------------------------ #
    def start(self) -> None:
        self._prepare_path()
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        old_umask = os.umask(0o177)
        try:
            listener.bind(str(self.path))
        except OSError:
            listener.close()
            raise
        finally:
            os.umask(old_umask)
        os.chmod(self.path, 0o600)
        listener.listen(self._max_clients)
        listener.settimeout(0.25)
        self._listener = listener
        self._thread = threading.Thread(
            target=self._accept_loop, name="gcp-accept", daemon=True
        )
        self._thread.start()

    def _prepare_path(self) -> None:
        if not self.path.exists() and not self.path.is_symlink():
            return
        if not stat.S_ISSOCK(os.lstat(self.path).st_mode):
            raise FileExistsError(f"{self.path} exists and is not a socket")
        probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        probe.settimeout(0.5)
        try:
            probe.connect(str(self.path))
        except OSError:
            self.path.unlink()  # stale socket from a crashed run
        else:
            raise OSError(f"{self.path} is already served by another process")
        finally:
            probe.close()

    def _accept_loop(self) -> None:
        assert self._listener is not None
        while not self._stop.is_set():
            try:
                conn, _ = self._listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            self._register(conn)

    def _register(self, conn: socket.socket) -> None:
        with self._lock:
            self._clients = [c for c in self._clients if c.alive]
            if len(self._clients) >= self._max_clients:
                conn.close()
                return
            client = _Client(conn, self._queue_size)
            self._clients.append(client)

        if self._provider is not None:
            try:
                data = b"".join(e.encode() for e in self._provider())
                if data:
                    # Chunk so one huge snapshot cannot overflow the queue.
                    for i in range(0, len(data), 64 * 1024):
                        client.queue.put_nowait(data[i:i + 64 * 1024])
            except queue.Full:
                client.shutdown()
                return
            except Exception:
                log.exception("snapshot provider failed")

        client.thread = threading.Thread(
            target=self._writer, args=(client,), name="gcp-writer", daemon=True
        )
        client.thread.start()

    def _writer(self, client: _Client) -> None:
        try:
            while client.alive and not self._stop.is_set():
                try:
                    item = client.queue.get(timeout=0.5)
                except queue.Empty:
                    if _peer_closed(client.sock):
                        break       # idle client hung up
                    continue
                if item is None:
                    break
                client.sock.sendall(item)
        except OSError:
            pass
        finally:
            client.shutdown()

    # ------------------------------------------------------------------ #
    def broadcast(self, events: Sequence[GCPEvent]) -> None:
        if not events:
            return
        with self._lock:
            clients = [c for c in self._clients if c.alive]
        if not clients:
            return
        data = b"".join(e.encode() for e in events)
        for client in clients:
            try:
                client.queue.put_nowait(data)
            except queue.Full:
                log.warning("dropping slow GCP client")
                client.shutdown()

    def close(self) -> None:
        self._stop.set()
        if self._listener is not None:
            with contextlib.suppress(OSError):
                self._listener.close()
        with self._lock:
            clients, self._clients = self._clients, []
        for client in clients:
            client.shutdown()
        if self._thread is not None:
            self._thread.join(timeout=2)
        with contextlib.suppress(OSError):
            if self.path.exists() and stat.S_ISSOCK(os.lstat(self.path).st_mode):
                self.path.unlink()


def stream_events(path: str | Path, timeout: float | None = None) -> Iterator[GCPEvent]:
    """Connect to a GCP socket and yield events until the server goes away.

    Lines that are not valid GCP events raise ``ValueError``.
    """
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    sock.connect(str(path))
    with contextlib.closing(sock), sock.makefile("rb") as reader:
        while True:
            line = reader.readline(MAX_EVENT_BYTES + 1)
            if not line:
                return
            if len(line) > MAX_EVENT_BYTES:
                raise ValueError("GCP line exceeds MAX_EVENT_BYTES")
            line = line.strip()
            if line:
                yield GCPEvent.decode(line)
