"""Runtime configuration shared by the GUI and the CLI."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class AppConfig:
    interval_ms: int = 1500
    db_path: str | None = None
    socket_path: str | None = None
    plugins_dir: str | None = None
    retention_hours: float = 24.0
    max_rows: int = 2_000_000

    def __post_init__(self) -> None:
        self.interval_ms = max(200, int(self.interval_ms))
        if self.plugins_dir:
            self.plugins_dir = str(Path(self.plugins_dir).expanduser())
