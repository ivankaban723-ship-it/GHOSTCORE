"""Turns raw /proc snapshots into CPU percentages and GCP events."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from ghostcore.collectors.procfs import ProcfsCollector, ProcessSnapshot, SystemStats
from ghostcore.core.protocol import EventType, GCPEvent

# A process only produces a ``process.sample`` event when something changed or
# it used a noticeable amount of CPU. This keeps the event history compact.
SAMPLE_CPU_THRESHOLD = 0.05


@dataclass(frozen=True, slots=True)
class PollResult:
    timestamp_ns: int
    interval_s: float
    snapshots: tuple[ProcessSnapshot, ...]
    cpu_percent: dict[str, float] = field(default_factory=dict)
    spawned: tuple[ProcessSnapshot, ...] = ()
    exited: tuple[ProcessSnapshot, ...] = ()
    system: SystemStats | None = None
    first: bool = False

    def cpu_of(self, node_id: str) -> float:
        return self.cpu_percent.get(node_id, 0.0)


class ProcessMonitor:
    """Stateful differ: call :meth:`poll` periodically."""

    def __init__(
        self,
        collector: ProcfsCollector | None = None,
        clock: Callable[[], float] = time.monotonic,
        wall_clock_ns: Callable[[], int] = time.time_ns,
    ) -> None:
        self.collector = collector or ProcfsCollector()
        self._clock = clock
        self._wall_clock_ns = wall_clock_ns
        self._prev: dict[str, ProcessSnapshot] | None = None
        self._prev_time = 0.0
        self._reported: dict[str, tuple[str, int]] = {}

    # ------------------------------------------------------------------ #
    def poll(self) -> PollResult:
        now = self._clock()
        wall_ns = self._wall_clock_ns()
        snapshots = self.collector.collect()
        current = {s.node_id: s for s in snapshots}
        previous = self._prev
        first = previous is None
        dt = 0.0 if first else now - self._prev_time

        cpu: dict[str, float] = {}
        spawned: list[ProcessSnapshot] = []
        exited: list[ProcessSnapshot] = []

        if previous is not None:
            ticks = max(1, self.collector.clock_ticks)
            for node_id, snap in current.items():
                old = previous.get(node_id)
                if old is None:
                    spawned.append(snap)
                elif dt > 0:
                    delta = max(0, snap.cpu_ticks - old.cpu_ticks)
                    cpu[node_id] = delta / ticks / dt * 100.0
            exited = [s for node_id, s in previous.items() if node_id not in current]

        self._prev = current  # replaced atomically; safe to read from other threads
        self._prev_time = now

        return PollResult(
            timestamp_ns=wall_ns,
            interval_s=dt,
            snapshots=tuple(snapshots),
            cpu_percent=cpu,
            spawned=tuple(spawned),
            exited=tuple(exited),
            system=self.collector.system_stats(process_count=len(snapshots)),
            first=first,
        )

    # ------------------------------------------------------------------ #
    def snapshot_events(self) -> list[GCPEvent]:
        """Full current state, used to bring new stream subscribers up to date."""
        current = self._prev or {}
        ts = self._wall_clock_ns()
        return [
            GCPEvent(EventType.PROCESS_SNAPSHOT, snap.to_payload(), ts)
            for snap in current.values()
        ]

    def to_events(self, result: PollResult) -> list[GCPEvent]:
        ts = result.timestamp_ns
        events: list[GCPEvent] = []

        if result.first:
            for snap in result.snapshots:
                events.append(GCPEvent(EventType.PROCESS_SNAPSHOT, snap.to_payload(), ts))
                self._reported[snap.node_id] = (snap.state, snap.memory_bytes)
        else:
            for snap in result.spawned:
                events.append(GCPEvent(EventType.PROCESS_SPAWNED, snap.to_payload(), ts))
            for snap in result.exited:
                self._reported.pop(snap.node_id, None)
                events.append(
                    GCPEvent(
                        EventType.PROCESS_EXITED,
                        {"pid": snap.pid, "node_id": snap.node_id, "name": snap.name},
                        ts,
                    )
                )
            for snap in result.snapshots:
                node_id = snap.node_id
                cpu = result.cpu_of(node_id)
                key = (snap.state, snap.memory_bytes)
                if cpu < SAMPLE_CPU_THRESHOLD and self._reported.get(node_id) == key:
                    continue
                self._reported[node_id] = key
                events.append(
                    GCPEvent(
                        EventType.PROCESS_SAMPLE,
                        {
                            "pid": snap.pid,
                            "node_id": node_id,
                            "cpu_percent": round(cpu, 2),
                            "memory_bytes": snap.memory_bytes,
                            "state": snap.state,
                            "threads": snap.num_threads,
                        },
                        ts,
                    )
                )

        if result.system is not None:
            events.append(GCPEvent(EventType.SYSTEM_SAMPLE, result.system.to_payload(), ts))
        return events
