"""Tiny thread-safe publish/subscribe bus for GCP events."""

from __future__ import annotations

import logging
import threading
from typing import Callable, Iterable, Sequence

from ghostcore.core.protocol import GCPEvent

log = logging.getLogger(__name__)

EventCallback = Callable[[GCPEvent], None]
BatchCallback = Callable[[Sequence[GCPEvent]], None]


class EventBus:
    """Synchronous fan-out. Subscribers run on the publisher's thread.

    A failing subscriber never breaks the others; its error is logged and
    counted in :attr:`errors`.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._single: list[tuple[tuple[str, ...] | None, EventCallback]] = []
        self._batch: list[BatchCallback] = []
        self.errors = 0

    def subscribe(
        self, callback: EventCallback, prefixes: Iterable[str] | None = None
    ) -> Callable[[], None]:
        """Receive events one by one, optionally only for type prefixes."""
        entry = (tuple(prefixes) if prefixes is not None else None, callback)
        with self._lock:
            self._single.append(entry)

        def unsubscribe() -> None:
            with self._lock:
                if entry in self._single:
                    self._single.remove(entry)

        return unsubscribe

    def subscribe_batch(self, callback: BatchCallback) -> Callable[[], None]:
        """Receive every published batch as a whole (database, socket...)."""
        with self._lock:
            self._batch.append(callback)

        def unsubscribe() -> None:
            with self._lock:
                if callback in self._batch:
                    self._batch.remove(callback)

        return unsubscribe

    def publish(self, event: GCPEvent) -> None:
        self.publish_many([event])

    def publish_many(self, events: Sequence[GCPEvent]) -> None:
        if not events:
            return
        with self._lock:
            single = list(self._single)
            batch = list(self._batch)

        for callback in batch:
            try:
                callback(events)
            except Exception:
                self.errors += 1
                log.exception("batch subscriber failed")

        for prefixes, callback in single:
            for event in events:
                if prefixes is not None and not event.event_type.startswith(prefixes):
                    continue
                try:
                    callback(event)
                except Exception:
                    self.errors += 1
                    log.exception("subscriber failed")
