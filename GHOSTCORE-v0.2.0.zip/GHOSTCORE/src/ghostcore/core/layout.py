"""Graph layouts: a deterministic radial tree and a live force simulation."""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Mapping, Sequence

import numpy as np

from ghostcore.collectors.procfs import ProcessSnapshot

Point = tuple[float, float]


# ---------------------------------------------------------------------- #
# Radial tree
# ---------------------------------------------------------------------- #
def radial_layout(
    processes: Sequence[ProcessSnapshot], ring_gap: float = 175.0
) -> dict[str, Point]:
    """Radial tree layout: process families orbit a central system root.

    Angular space is allotted by leaf count. Cycles and orphans are handled:
    every process always receives a position.
    """
    by_pid = {p.pid: p for p in processes}
    children: dict[int, list[int]] = defaultdict(list)
    roots: list[int] = []
    for process in processes:
        if process.ppid in by_pid and process.ppid != process.pid:
            children[process.ppid].append(process.pid)
        else:
            roots.append(process.pid)
    for child_ids in children.values():
        child_ids.sort(key=lambda pid: (by_pid[pid].name.lower(), pid))
    roots.sort(key=lambda pid: (by_pid[pid].name.lower(), pid))

    visited: set[int] = set()
    leaf_count: dict[int, int] = {}

    def count_leaves(pid: int, path: frozenset[int]) -> int:
        if pid in path or pid in visited:
            return 1
        visited.add(pid)
        next_path = path | {pid}
        valid = [kid for kid in children.get(pid, []) if kid not in next_path]
        count = sum(count_leaves(kid, next_path) for kid in valid) if valid else 1
        leaf_count[pid] = max(1, count)
        return leaf_count[pid]

    for root_pid in roots:
        count_leaves(root_pid, frozenset())
    for process in processes:
        if process.pid not in leaf_count:
            count_leaves(process.pid, frozenset())

    positions: dict[str, Point] = {}
    visited.clear()
    root_total = max(1, sum(leaf_count.get(pid, 1) for pid in roots))
    single_root = len(roots) == 1
    root_radius = 0.0 if single_root else 170.0

    def place(pid: int, depth: int, angle_start: float, angle_span: float) -> None:
        if pid in visited:
            return
        visited.add(pid)
        angle = angle_start + angle_span / 2
        radius = 0.0 if depth == 0 and single_root else root_radius + depth * ring_gap
        positions[by_pid[pid].node_id] = (
            math.cos(angle) * radius,
            math.sin(angle) * radius,
        )
        kids = [kid for kid in children.get(pid, []) if kid not in visited]
        if not kids:
            return
        total = sum(leaf_count.get(kid, 1) for kid in kids)
        cursor = angle_start
        for kid in kids:
            share = angle_span * leaf_count.get(kid, 1) / max(1, total)
            place(kid, depth + 1, cursor, share)
            cursor += share

    if single_root:
        place(roots[0], 0, -math.pi, 2 * math.pi)
    else:
        cursor = -math.pi / 2
        for root_pid in roots:
            share = 2 * math.pi * leaf_count.get(root_pid, 1) / root_total
            place(root_pid, 0, cursor, share)
            cursor += share

    leftovers = [p.pid for p in processes if p.pid not in visited]
    for index, pid in enumerate(leftovers):
        angle = 2 * math.pi * index / max(1, len(leftovers))
        positions[by_pid[pid].node_id] = (math.cos(angle) * 300, math.sin(angle) * 300)
    return positions


# ---------------------------------------------------------------------- #
# Force simulation
# ---------------------------------------------------------------------- #
class ForceLayout:
    """Stateful force-directed simulation (d3-force style cooling).

    Cost per step is O(n^2) in vectorised numpy, about 10 ms per step at 1000 nodes
    (:data:`MAX_NODES` is the interactive cap). The simulation goes to sleep once it has settled, so a
    quiet system costs no CPU; call :meth:`reheat` after the graph changes.
    """

    MAX_NODES = 900

    def __init__(
        self,
        link_distance: float = 80.0,
        repulsion: float = 900.0,
        link_strength: float = 0.35,
        gravity: float = 0.012,
        damping: float = 0.6,
        alpha_decay: float = 0.02,
        alpha_min: float = 0.01,
        seed: int = 7,
    ) -> None:
        self.link_distance = link_distance
        self.repulsion = repulsion
        self.link_strength = link_strength
        self.gravity = gravity
        self.damping = damping
        self.alpha_decay = alpha_decay
        self.alpha_min = alpha_min
        self._rng = np.random.default_rng(seed)
        self._ids: list[str] = []
        self._index: dict[str, int] = {}
        self._pos = np.zeros((0, 2), dtype=np.float64)
        self._vel = np.zeros((0, 2), dtype=np.float64)
        self._src = np.zeros(0, dtype=np.int64)
        self._dst = np.zeros(0, dtype=np.int64)
        self._pinned: dict[str, Point] = {}
        self.alpha = 0.0

    # -------------------------------------------------------------- #
    @property
    def asleep(self) -> bool:
        return self.alpha < self.alpha_min and not self._pinned

    def __len__(self) -> int:
        return len(self._ids)

    def set_graph(
        self,
        node_ids: Sequence[str],
        edges: Sequence[tuple[str, str]],
        initial: Mapping[str, Point] | None = None,
    ) -> None:
        """Replace the graph, keeping positions of nodes that already exist.

        ``edges`` are ``(parent_id, child_id)`` pairs. New nodes start next to
        their parent (or at ``initial``) so spawns look like they emerge from
        the parent process.
        """
        old_pos = {nid: self._pos[i].copy() for nid, i in self._index.items()}
        old_vel = {nid: self._vel[i].copy() for nid, i in self._index.items()}
        parent_of = {child: parent for parent, child in edges}

        ids = list(node_ids)
        n = len(ids)
        pos = np.zeros((n, 2), dtype=np.float64)
        vel = np.zeros((n, 2), dtype=np.float64)
        for i, nid in enumerate(ids):
            if nid in old_pos:
                pos[i] = old_pos[nid]
                vel[i] = old_vel[nid]
            elif initial is not None and nid in initial:
                pos[i] = initial[nid]
            else:
                anchor = old_pos.get(parent_of.get(nid, ""))
                if anchor is None and initial is not None:
                    anchor = initial.get(parent_of.get(nid, ""))
                base = np.asarray(anchor if anchor is not None else (0.0, 0.0))
                angle = self._rng.uniform(0, 2 * math.pi)
                spread = 25.0 if anchor is not None else 150.0
                pos[i] = base + spread * np.array([math.cos(angle), math.sin(angle)])

        index = {nid: i for i, nid in enumerate(ids)}
        pairs = [(index[a], index[b]) for a, b in edges if a in index and b in index and a != b]
        self._ids = ids
        self._index = index
        self._pos = pos
        self._vel = vel
        self._src = np.array([p[0] for p in pairs], dtype=np.int64)
        self._dst = np.array([p[1] for p in pairs], dtype=np.int64)
        self._pinned = {k: v for k, v in self._pinned.items() if k in index}

    def reheat(self, alpha: float = 1.0) -> None:
        self.alpha = max(self.alpha, alpha)

    def pin(self, node_id: str, x: float, y: float) -> None:
        if node_id in self._index:
            self._pinned[node_id] = (x, y)
            self.reheat(0.3)

    def unpin(self, node_id: str) -> None:
        self._pinned.pop(node_id, None)
        self.reheat(0.3)

    def positions(self) -> dict[str, Point]:
        return {nid: (float(p[0]), float(p[1])) for nid, p in zip(self._ids, self._pos)}

    # -------------------------------------------------------------- #
    def step(self, iterations: int = 1) -> bool:
        """Advance the simulation. Returns True while it is still moving."""
        n = len(self._ids)
        if n == 0:
            return False
        for _ in range(max(1, iterations)):
            self._step_once()
        return not self.asleep

    def _repulsion_force(self, pos: np.ndarray) -> np.ndarray:
        """All-pairs 1/d repulsion, computed on separate x/y planes (fast)."""
        x, y = pos[:, 0], pos[:, 1]
        dx = x[:, None] - x[None, :]
        dy = y[:, None] - y[None, :]
        d2 = dx * dx + dy * dy
        np.fill_diagonal(d2, np.inf)
        if (d2 < 1e-6).any():
            # Coincident nodes get a tiny random push apart.
            pos += self._rng.normal(0.0, 0.5, size=pos.shape)
            return self._repulsion_force(pos)
        np.maximum(d2, 25.0, out=d2)  # soften very short range
        inv = 1.0 / d2
        dx *= inv
        dy *= inv
        return np.stack([dx.sum(axis=1), dy.sum(axis=1)], axis=1) * self.repulsion

    def _step_once(self) -> None:
        n = len(self._ids)
        pos, vel = self._pos, self._vel
        for nid, (x, y) in self._pinned.items():
            i = self._index[nid]
            pos[i] = (x, y)
            vel[i] = 0.0

        alpha = self.alpha
        if n > 1:
            force = self._repulsion_force(pos)
            vel += force * alpha

        if len(self._src):
            d = pos[self._dst] - pos[self._src]
            length = np.sqrt((d * d).sum(axis=1))
            length = np.maximum(length, 1e-6)
            pull = (length - self.link_distance) / length * self.link_strength
            f = d * pull[:, None]
            np.add.at(vel, self._src, f)
            np.add.at(vel, self._dst, -f)

        vel -= pos * self.gravity
        vel *= self.damping
        # Bound the step so one bad frame cannot fling nodes across the plane.
        np.clip(vel, -60.0, 60.0, out=vel)
        pos += vel

        for nid, (x, y) in self._pinned.items():
            i = self._index[nid]
            pos[i] = (x, y)
            vel[i] = 0.0

        self.alpha = max(0.0, alpha - alpha * self.alpha_decay)
        if self.alpha < self.alpha_min and not self._pinned:
            vel[:] = 0.0
