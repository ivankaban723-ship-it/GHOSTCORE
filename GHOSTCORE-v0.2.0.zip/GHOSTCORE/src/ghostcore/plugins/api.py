"""Public API for GHOSTCORE plugins."""

from __future__ import annotations

from typing import Any, Sequence

from ghostcore.core.protocol import GCPEvent

# Permissions a plugin may declare. They are checked when the plugin is
# registered; they gate what the host is willing to load, they do NOT sandbox
# the plugin's Python code.
KNOWN_PERMISSIONS = frozenset({"process.read", "system.read", "fs.read", "net"})


class GhostPlugin:
    """Base class for plugins.

    Override :meth:`on_poll` to react to every process poll, and/or
    :meth:`collect` to emit events on your own. Event types must use their own
    namespace (e.g. ``alert.zombie``); ``process.`` and ``system.`` are
    reserved for the core.
    """

    name = "unnamed-plugin"
    version = "0.1.0"
    permissions: Sequence[str] = ()

    def start(self) -> None:
        """Called when the plugin is enabled."""

    def collect(self) -> list[GCPEvent]:
        """Return events produced by this plugin on its own schedule."""
        return []

    def on_poll(self, result: Any) -> list[GCPEvent]:
        """Called after each process poll with a ``PollResult``."""
        return []

    def stop(self) -> None:
        """Called when the plugin is disabled."""

    def metadata(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "permissions": sorted(self.permissions),
        }
