"""Plugin lifecycle manager with directory discovery and fault isolation."""

from __future__ import annotations

import importlib.util
import inspect
import logging
from pathlib import Path
from typing import Any, Iterable

from ghostcore.core.protocol import EventType, GCPEvent
from ghostcore.plugins.api import KNOWN_PERMISSIONS, GhostPlugin

log = logging.getLogger(__name__)

DEFAULT_ALLOWED_PERMISSIONS = frozenset({"process.read", "system.read"})
MAX_CONSECUTIVE_FAILURES = 5


class PluginManager:
    def __init__(
        self, allowed_permissions: Iterable[str] = DEFAULT_ALLOWED_PERMISSIONS
    ) -> None:
        self.allowed_permissions = frozenset(allowed_permissions)
        self._plugins: dict[str, GhostPlugin] = {}
        self._failures: dict[str, int] = {}
        self._disabled: set[str] = set()
        self.rejected: list[str] = []   # human-readable reasons, for the UI/CLI
        self.dropped_events = 0

    # ------------------------------------------------------------------ #
    def register(self, plugin: GhostPlugin) -> None:
        name = plugin.name.strip()
        if not name or name == "unnamed-plugin":
            raise ValueError("Plugin must have a meaningful name")
        if name in self._plugins:
            raise ValueError(f"Plugin already registered: {name}")

        requested = set(plugin.permissions)
        unknown = requested - KNOWN_PERMISSIONS
        if unknown:
            raise PermissionError(
                f"Plugin {name} requests unknown permissions: {sorted(unknown)}"
            )
        denied = requested - self.allowed_permissions
        if denied:
            raise PermissionError(
                f"Plugin {name} requests permissions that are not allowed: {sorted(denied)}"
            )
        self._plugins[name] = plugin

    def discover(self, directory: str | Path) -> list[str]:
        """Load every ``*.py`` plugin from a directory. Returns loaded names.

        WARNING: this imports and executes the files. Only point it at a
        directory you trust. Files that fail to import or register are skipped
        and described in :attr:`rejected`.
        """
        loaded: list[str] = []
        base = Path(directory).expanduser()
        if not base.is_dir():
            self.rejected.append(f"{base}: not a directory")
            return loaded

        for path in sorted(base.glob("*.py")):
            if path.name.startswith("_"):
                continue
            try:
                module = self._import_file(path)
            except Exception as exc:
                self.rejected.append(f"{path.name}: import failed ({type(exc).__name__}: {exc})")
                continue
            for _, cls in inspect.getmembers(module, inspect.isclass):
                if (
                    issubclass(cls, GhostPlugin)
                    and cls is not GhostPlugin
                    and cls.__module__ == module.__name__
                ):
                    try:
                        plugin = cls()
                        self.register(plugin)
                        loaded.append(plugin.name)
                    except Exception as exc:
                        self.rejected.append(f"{path.name}:{cls.__name__}: {exc}")
        return loaded

    @staticmethod
    def _import_file(path: Path):
        spec = importlib.util.spec_from_file_location(f"ghostcore_plugin_{path.stem}", path)
        if spec is None or spec.loader is None:
            raise ImportError("cannot create import spec")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    # ------------------------------------------------------------------ #
    def start_all(self) -> None:
        started: list[GhostPlugin] = []
        try:
            for plugin in self._plugins.values():
                plugin.start()
                started.append(plugin)
        except Exception:
            for plugin in reversed(started):
                try:
                    plugin.stop()
                except Exception:
                    pass
            raise

    def collect_all(self) -> list[GCPEvent]:
        return self._run(lambda p: p.collect())

    def dispatch_poll(self, result: Any) -> list[GCPEvent]:
        return self._run(lambda p: p.on_poll(result))

    def _run(self, call) -> list[GCPEvent]:
        events: list[GCPEvent] = []
        for name, plugin in self._plugins.items():
            if name in self._disabled:
                continue
            try:
                produced = call(plugin) or []
            except Exception as exc:
                self._record_failure(name, exc)
                continue
            self._failures[name] = 0
            for event in produced:
                if self._valid(event):
                    events.append(event)
                else:
                    self.dropped_events += 1
        return events

    @staticmethod
    def _valid(event: object) -> bool:
        return (
            isinstance(event, GCPEvent)
            and bool(event.event_type)
            and not event.event_type.startswith(EventType.RESERVED_PREFIXES)
        )

    def _record_failure(self, name: str, exc: Exception) -> None:
        count = self._failures.get(name, 0) + 1
        self._failures[name] = count
        log.warning("plugin %s failed (%d): %s", name, count, exc)
        if count >= MAX_CONSECUTIVE_FAILURES:
            self._disabled.add(name)
            self.rejected.append(
                f"{name}: disabled after {count} consecutive failures ({exc})"
            )

    def stop_all(self) -> None:
        for plugin in reversed(list(self._plugins.values())):
            try:
                plugin.stop()
            except Exception:
                # Continue stopping the remaining plugins.
                pass

    def list_plugins(self) -> list[dict]:
        return [
            {**plugin.metadata(), "enabled": name not in self._disabled}
            for name, plugin in self._plugins.items()
        ]
