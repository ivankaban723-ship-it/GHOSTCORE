"""Read-only Linux process collector based on /proc."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from ghostcore.core.protocol import EventType, GCPEvent

PROC_ROOT = Path("/proc")

try:
    CLOCK_TICKS = int(os.sysconf("SC_CLK_TCK"))
except (ValueError, OSError, AttributeError):  # pragma: no cover - non-Linux
    CLOCK_TICKS = 100

MAX_CMDLINE_CHARS = 1024


@dataclass(frozen=True, slots=True)
class ProcessSnapshot:
    pid: int
    ppid: int
    name: str
    state: str
    memory_bytes: int
    start_ticks: int
    cpu_ticks: int = 0      # utime + stime, in clock ticks (cumulative)
    num_threads: int = 1
    uid: int = -1

    @property
    def node_id(self) -> str:
        # PID can be reused, so include the process start time.
        return f"{self.pid}:{self.start_ticks}"

    def to_payload(self) -> dict:
        return {
            "pid": self.pid,
            "ppid": self.ppid,
            "node_id": self.node_id,
            "name": self.name,
            "state": self.state,
            "memory_bytes": self.memory_bytes,
            "cpu_ticks": self.cpu_ticks,
            "threads": self.num_threads,
            "uid": self.uid,
        }


@dataclass(frozen=True, slots=True)
class SystemStats:
    load1: float
    load5: float
    load15: float
    mem_total_bytes: int
    mem_available_bytes: int
    uptime_s: float
    process_count: int = 0

    @property
    def mem_used_ratio(self) -> float:
        if self.mem_total_bytes <= 0:
            return 0.0
        used = self.mem_total_bytes - self.mem_available_bytes
        return max(0.0, min(1.0, used / self.mem_total_bytes))

    def to_payload(self) -> dict:
        return {
            "load1": self.load1,
            "load5": self.load5,
            "load15": self.load15,
            "mem_total_bytes": self.mem_total_bytes,
            "mem_available_bytes": self.mem_available_bytes,
            "uptime_s": self.uptime_s,
            "process_count": self.process_count,
        }


def process_age_seconds(
    snapshot: ProcessSnapshot, uptime_s: float, clock_ticks: int = CLOCK_TICKS
) -> float:
    """Seconds since the process started, given the system uptime."""
    started_at = snapshot.start_ticks / max(1, clock_ticks)
    return max(0.0, uptime_s - started_at)


class ProcfsCollector:
    def __init__(self, proc_root: Path = PROC_ROOT) -> None:
        self.proc_root = Path(proc_root)
        self.clock_ticks = CLOCK_TICKS
        try:
            self._page_size = int(os.sysconf("SC_PAGE_SIZE"))
        except (ValueError, OSError, AttributeError):
            self._page_size = 4096

    # ------------------------------------------------------------------ #
    # Processes
    # ------------------------------------------------------------------ #
    def collect(self) -> list[ProcessSnapshot]:
        processes: list[ProcessSnapshot] = []
        try:
            entries = list(self.proc_root.iterdir())
        except OSError:
            return processes

        for entry in entries:
            if not entry.name.isdigit():
                continue
            try:
                processes.append(self._read_process(int(entry.name)))
            except (OSError, ValueError, IndexError):
                # Processes can exit between listing /proc and reading files.
                continue

        return processes

    def _read_process(self, pid: int) -> ProcessSnapshot:
        process_dir = self.proc_root / str(pid)
        stat = (process_dir / "stat").read_text(encoding="utf-8", errors="replace")
        left = stat.find("(")
        right = stat.rfind(")")

        if left < 0 or right <= left:
            raise ValueError("Malformed /proc/PID/stat")

        parsed_pid = int(stat[:left].strip())
        name = stat[left + 1:right]
        fields = stat[right + 2:].split()

        # After the final ") ": fields[0] is field 3 (state), fields[1] is
        # field 4 (ppid), fields[11]/[12] are fields 14/15 (utime/stime),
        # fields[17] is field 20 (num_threads), fields[19] is field 22
        # (starttime).
        if len(fields) <= 19:
            raise ValueError("Incomplete /proc/PID/stat")

        state = fields[0]
        ppid = int(fields[1])
        cpu_ticks = int(fields[11]) + int(fields[12])
        num_threads = max(1, int(fields[17]))
        start_ticks = int(fields[19])

        memory_bytes = 0
        uid = -1
        try:
            status = (process_dir / "status").read_text(
                encoding="utf-8", errors="replace"
            )
            for line in status.splitlines():
                if line.startswith("VmRSS:"):
                    memory_bytes = int(line.split()[1]) * 1024
                elif line.startswith("Uid:"):
                    uid = int(line.split()[1])
        except (OSError, ValueError, IndexError):
            pass

        return ProcessSnapshot(
            pid=parsed_pid,
            ppid=ppid,
            name=name or "unknown",
            state=state,
            memory_bytes=memory_bytes,
            start_ticks=start_ticks,
            cpu_ticks=cpu_ticks,
            num_threads=num_threads,
            uid=uid,
        )

    def read_cmdline(self, pid: int) -> str:
        """Command line of one process, read on demand.

        Command lines frequently contain secrets (tokens, passwords), so the
        collector never includes them in GCP events, the database or the
        socket stream. Only the local inspector asks for them.
        """
        try:
            raw = (self.proc_root / str(int(pid)) / "cmdline").read_bytes()
        except (OSError, ValueError):
            return ""
        text = raw.replace(b"\0", b" ").decode("utf-8", errors="replace").strip()
        return text[:MAX_CMDLINE_CHARS]

    # ------------------------------------------------------------------ #
    # System
    # ------------------------------------------------------------------ #
    def system_stats(self, process_count: int = 0) -> SystemStats | None:
        try:
            load = (self.proc_root / "loadavg").read_text().split()
            load1, load5, load15 = (float(v) for v in load[:3])
            uptime = float((self.proc_root / "uptime").read_text().split()[0])
            meminfo = (self.proc_root / "meminfo").read_text()
        except (OSError, ValueError, IndexError):
            return None

        values: dict[str, int] = {}
        for line in meminfo.splitlines():
            key, _, rest = line.partition(":")
            parts = rest.split()
            if key in ("MemTotal", "MemAvailable", "MemFree") and parts:
                try:
                    values[key] = int(parts[0]) * 1024
                except ValueError:
                    continue
        total = values.get("MemTotal", 0)
        available = values.get("MemAvailable", values.get("MemFree", 0))
        return SystemStats(
            load1=load1,
            load5=load5,
            load15=load15,
            mem_total_bytes=total,
            mem_available_bytes=available,
            uptime_s=uptime,
            process_count=process_count,
        )

    # ------------------------------------------------------------------ #
    # Events
    # ------------------------------------------------------------------ #
    def collect_events(self) -> list[GCPEvent]:
        return [
            GCPEvent(event_type=EventType.PROCESS_SNAPSHOT, payload=p.to_payload())
            for p in self.collect()
        ]
