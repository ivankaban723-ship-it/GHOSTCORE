"""Example plugin: raises an ``alert.zombie`` event for each new zombie process.

Drop this file into a directory and start GHOSTCORE with
``--plugins-dir <that directory>``.
"""

from ghostcore.core.protocol import GCPEvent
from ghostcore.plugins.api import GhostPlugin


class ZombieWatch(GhostPlugin):
    name = "zombie-watch"
    version = "1.0.0"
    permissions = ("process.read",)

    def start(self) -> None:
        self._seen: set[str] = set()

    def on_poll(self, result):
        zombies = {s.node_id: s for s in result.snapshots if s.state == "Z"}
        fresh = [s for node_id, s in zombies.items() if node_id not in self._seen]
        self._seen = set(zombies)
        return [
            GCPEvent(
                "alert.zombie",
                {"node_id": s.node_id, "pid": s.pid, "ppid": s.ppid, "name": s.name},
                result.timestamp_ns,
            )
            for s in fresh
        ]
